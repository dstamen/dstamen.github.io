# The provider resolves the iSCSI targets itself and installs MountIscsiLinux or
# MountIscsiWindows to match the VM's OS.
resource "everpure_azure_virtual_machine_connection" "vm" {
  for_each            = local.vms
  virtual_machine_id  = local.vm_ids[each.key]
  volume_group_ids    = [everpure_azure_volume_group.vg[each.key].id]
  iscsi_session_count = var.iscsi_sessions

  # Windows only: first MPIO setup needs a reboot to finish. No effect on Linux.
  reboot_allowed = each.value.os == "windows"

  # Connecting a group with no volumes fails, and volumes created later need a rescan.
  depends_on = [everpure_azure_volume.vol]
}

output "iscsi_targets" {
  value = { for k, c in everpure_azure_virtual_machine_connection.vm : local.vms[k].name => c.resolved_targets }
}
