variable "subscription_id" {
  type = string
}

variable "resource_group" {
  type        = string
  description = "Resource group the storage pool is created in."
}

variable "location" {
  type = string
}

variable "zone" {
  type        = string
  description = "Availability zone for the pool. Changing it replaces the pool."
}

variable "reservation_name" {
  type        = string
  description = "Name of the existing reservation that funds the pool."
}

variable "reservation_resource_group" {
  type        = string
  description = "Resource group the reservation lives in."
}

variable "subnet_id" {
  type        = string
  description = "Full resource ID of a subnet delegated to PureStorage.Block/storagePools."
}

variable "pool_name" {
  type = string
}

variable "bandwidth" {
  type        = number
  description = "Provisioned bandwidth in MB/s. Minimum 800, can be changed in place."
  default     = 800
}

variable "platform_console_enabled" {
  type        = bool
  description = "Adds the platform_console block to the pool. Removing it disables console access."
  default     = false
}

variable "platform_console_gui_api_enabled" {
  type        = bool
  description = "GUI and REST API access. One switch because the provider requires gui_enabled = api_enabled."
  default     = true
}

variable "platform_console_cli_enabled" {
  type        = bool
  description = "CLI (SSH) access. At least one of this or GUI/API must be on when the console is enabled."
  default     = false
}

variable "console_ssh_username" {
  type        = string
  description = "Console SSH user created once after the pool, with ssh_public_key_path. Null skips it."
  default     = "everpure-ssh"
}

variable "console_ssh_role" {
  type    = string
  default = "read_only"

  validation {
    condition     = contains(["array_admin", "read_only"], var.console_ssh_role)
    error_message = "console_ssh_role must be array_admin or read_only."
  }
}

variable "console_credentials" {
  type        = bool
  description = "Issue temporary console credentials into .console-creds. Each request invalidates the last one."
  default     = false
}

variable "vg_iops_limit" {
  type    = number
  default = null
}

variable "snapshot_frequency" {
  type        = string
  description = "ISO 8601 duration, e.g. PT1H. Leave null for no snapshot schedule."
  default     = null
}

variable "snapshot_retention" {
  type        = string
  description = "ISO 8601 duration, e.g. P7D. Only used when snapshot_frequency is set."
  default     = "P7D"
}

variable "vol_size_gib" {
  type    = number
  default = 100
}

variable "vm_resource_group" {
  type        = string
  description = "Resource group the test VMs are created in."
}

variable "vm_subnet_id" {
  type        = string
  description = "Subnet for the VM NICs. Needs a route to the pool subnet."
}

variable "vm_prefix" {
  type        = string
  description = "VM names are <prefix>-lin and <prefix>-win. Volume groups use the same names."
}

variable "vm_size" {
  type    = string
  default = "Standard_D2s_v5"
}

variable "admin_username" {
  type    = string
  default = "azureuser"
}

variable "ssh_public_key_path" {
  type        = string
  description = "Public key for the Linux VM admin and the console SSH user."
  default     = "~/.ssh/id_rsa.pub"
}

variable "iscsi_sessions" {
  type    = number
  default = 2
}

variable "allow_destroy" {
  type        = bool
  description = "Flip to true and apply before terraform destroy. Turns off deletion_protection and eradicates on destroy so the pool can actually be deleted."
  default     = false
}

variable "tags" {
  type    = map(string)
  default = {}
}
