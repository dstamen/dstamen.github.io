terraform {
  required_version = ">= 1.16" # actions with caller (console.tf)

  required_providers {
    # Local name must be "everpure" -- resource types start with everpure_.
    everpure = {
      source  = "PureStorage-OpenConnect/everpure-azure"
      version = "1.0.0"
    }
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0"
    }
    random = {
      source = "hashicorp/random"
    }
  }
}

# Auth is the same chain as azurerm; with nothing set it uses az login.
provider "everpure" {
  subscription_id = var.subscription_id
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}
