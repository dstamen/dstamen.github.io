# Create takes about 30 min. Provider timeouts default to 95m create/delete.
resource "everpure_azure_storage_pool" "pool" {
  name                          = var.pool_name
  resource_group_name           = var.resource_group
  location                      = var.location
  zone                          = var.zone
  reservation_id                = data.everpure_azure_reservation.lab.id
  provisioned_bandwidth_in_mbps = var.bandwidth
  tags                          = var.tags

  vnet_injection {
    subnet_id = var.subnet_id
  }

  # gui_enabled and api_enabled must match. Removing the block disables the console.
  dynamic "platform_console" {
    for_each = var.platform_console_enabled ? [1] : []
    content {
      gui_enabled = var.platform_console_gui_api_enabled
      api_enabled = var.platform_console_gui_api_enabled
      cli_enabled = var.platform_console_cli_enabled
    }
  }

  # Creates the console SSH user (console.tf) once, right after the pool.
  lifecycle {
    action_trigger {
      events    = [after_create]
      condition = var.platform_console_enabled && var.console_ssh_username != null
      actions   = [action.everpure_azure_create_platform_console_ssh_user.console]
    }
  }
}

output "storage_pool_id" {
  value = everpure_azure_storage_pool.pool.id
}

output "storage_pool_provisioned_iops" {
  value = everpure_azure_storage_pool.pool.provisioned_iops
}
