locals {
  # One VM per OS, each with its own volume group + volume. Sharing a volume
  # across a Windows and Linux host would have both formatting the same LUN.
  vms = {
    lin = { name = "${var.vm_prefix}-lin", os = "linux" }
    win = { name = "${var.vm_prefix}-win", os = "windows" }
  }

  vm_ids = {
    lin = azurerm_linux_virtual_machine.lin.id
    win = azurerm_windows_virtual_machine.win.id
  }
}
