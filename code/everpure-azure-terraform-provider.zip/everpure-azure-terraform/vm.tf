resource "azurerm_network_interface" "vm" {
  for_each            = local.vms
  name                = "${each.value.name}-nic"
  location            = var.location
  resource_group_name = var.vm_resource_group
  tags                = var.tags

  ip_configuration {
    name                          = "internal"
    subnet_id                     = var.vm_subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

resource "azurerm_linux_virtual_machine" "lin" {
  name                  = local.vms.lin.name
  location              = var.location
  resource_group_name   = var.vm_resource_group
  size                  = var.vm_size
  zone                  = var.zone
  admin_username        = var.admin_username
  network_interface_ids = [azurerm_network_interface.vm["lin"].id]
  tags                  = var.tags

  admin_ssh_key {
    username   = var.admin_username
    public_key = file(pathexpand(var.ssh_public_key_path))
  }

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Premium_LRS"
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "ubuntu-24_04-lts"
    sku       = "server"
    version   = "latest"
  }
}

resource "random_password" "win_admin" {
  length           = 24
  min_upper        = 2
  min_lower        = 2
  min_numeric      = 2
  min_special      = 2
  override_special = "!@#%^*-_=+"
}

resource "azurerm_windows_virtual_machine" "win" {
  name                  = local.vms.win.name
  computer_name         = substr(replace(local.vms.win.name, "-", ""), 0, 15) # NetBIOS limit
  location              = var.location
  resource_group_name   = var.vm_resource_group
  size                  = var.vm_size
  zone                  = var.zone
  admin_username        = var.admin_username
  admin_password        = random_password.win_admin.result
  network_interface_ids = [azurerm_network_interface.vm["win"].id]
  tags                  = var.tags

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Premium_LRS"
  }

  source_image_reference {
    publisher = "MicrosoftWindowsServer"
    offer     = "WindowsServer"
    sku       = "2022-datacenter-azure-edition"
    version   = "latest"
  }
}

output "vm_private_ips" {
  value = { for k, nic in azurerm_network_interface.vm : local.vms[k].name => nic.private_ip_address }
}

# terraform output -raw win_admin_password
output "win_admin_password" {
  value     = random_password.win_admin.result
  sensitive = true
}
