terraform {
  # Local state. Swap for a cloud {} or backend "azurerm" {} block to share state.
  backend "local" {}
}
