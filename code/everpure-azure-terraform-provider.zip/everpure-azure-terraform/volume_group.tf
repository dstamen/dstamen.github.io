resource "everpure_azure_volume_group" "vg" {
  for_each        = local.vms
  name            = each.value.name
  storage_pool_id = everpure_azure_storage_pool.pool.id
  iops_limit      = var.vg_iops_limit
  tags            = var.tags

  dynamic "snapshot_protection_policy" {
    for_each = var.snapshot_frequency == null ? [] : [1]
    content {
      frequency = var.snapshot_frequency
      retention = var.snapshot_retention
    }
  }

  # Defaults are true/false, which soft-deletes on destroy and then blocks the
  # pool delete until eradication. See allow_destroy in variables.tf.
  deletion_protection  = !var.allow_destroy
  eradicate_on_destroy = var.allow_destroy
}

output "volume_group_ids" {
  value = { for k, vg in everpure_azure_volume_group.vg : k => vg.id }
}
