resource "everpure_azure_volume" "vol" {
  for_each                = local.vms
  name                    = "data1"
  volume_group_id         = everpure_azure_volume_group.vg[each.key].id
  provisioned_size_in_gib = var.vol_size_gib # grow only

  deletion_protection  = !var.allow_destroy
  eradicate_on_destroy = var.allow_destroy
}

# Matches the disk serial inside the guest (lsblk -o NAME,SERIAL / Get-Disk).
output "volume_serial_numbers" {
  value = { for k, v in everpure_azure_volume.vol : local.vms[k].name => v.serial_number }
}
