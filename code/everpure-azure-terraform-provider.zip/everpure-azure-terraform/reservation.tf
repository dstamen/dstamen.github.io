# Read-only. Creating or moving a reservation is a Marketplace purchase and a
# permanent delete on destroy, so the shared lab reservation stays out of state.
data "everpure_azure_reservation" "lab" {
  name                = var.reservation_name
  resource_group_name = var.reservation_resource_group
}

output "reservation" {
  value = {
    id                 = data.everpure_azure_reservation.lab.id
    location           = data.everpure_azure_reservation.lab.location
    marketplace_status = data.everpure_azure_reservation.lab.marketplace_subscription_status
    offer              = data.everpure_azure_reservation.lab.offer
  }
}
