# everpure-azure-terraform

Deploys Everpure Cloud Azure Native storage with the
[Everpure Azure provider](https://registry.terraform.io/providers/PureStorage-OpenConnect/everpure-azure/latest)
(`PureStorage-OpenConnect/everpure-azure` 1.0.0): a storage pool, a volume group and volume per VM,
and iSCSI connections to a new Linux and Windows VM.

## Prerequisites

- An existing **Everpure Cloud Reservation** in the region you deploy to
- The `PureStorage.Block` resource provider registered on the subscription
- A subnet delegated to `PureStorage.Block/storagePools` for the pool
- A subnet for the VMs that can reach the pool subnet (the VMs get private IPs only)
- Terraform 1.16 or newer
- The Azure CLI, logged in with `az login`

## Usage

```bash
cp terraform.auto.tfvars.example terraform.auto.tfvars   # fill in your values
terraform init
terraform plan -out=tfplan
terraform apply tfplan   # pool create takes about 30 min
```

State is local (`backend.tf`). Swap in a `cloud` or `azurerm` backend to share it. With HCP
Terraform, run the workspace in **Local** execution mode so the Azure CLI login is used.

## What it builds

| Resource | File |
|---|---|
| `everpure_azure_storage_pool`, with platform console access | `pool.tf` |
| `everpure_azure_reservation` data source, so the pool gets the reservation ID by name | `reservation.tf` |
| Linux (Ubuntu 24.04) and Windows (Server 2022) VMs | `vm.tf` |
| `everpure_azure_volume_group` per VM, with an optional snapshot schedule | `volume_group.tf` |
| `everpure_azure_volume` `data1` per VM | `volume.tf` |
| `everpure_azure_virtual_machine_connection` per VM | `vm_connection.tf` |
| Console SSH user and on-demand activation credentials | `console.tf` |

A volume added to a volume group that a VM is already connected to needs
`iscsiadm -m session --rescan` on the guest before it shows up.

Snapshots (a manual snapshot, a volume restored from it and a cloned volume group) are in
`snapshot`, which Terraform ignores. Rename it to `snapshot.tf` to turn them on, and set
`snapshot_frequency` for a schedule.

## Console

The console SSH user is created once, right after the pool, by the pool's `action_trigger`, using
`ssh_public_key_path`. The console is only reachable from inside the VNet, so SSH to a VM there
with agent forwarding (`-A`) and then to the management IP in the `console` output.

Temporary credentials for the default console user are off by default, because every request
invalidates the previous one:

```bash
terraform apply -var console_credentials=true   # writes .console-creds (0600, gitignored)
```

## Teardown

Volume groups and volumes default to `deletion_protection = true` and soft-delete on destroy,
and a soft-deleted volume group or volume blocks the pool delete. Turn protection off first:

```bash
terraform apply -var allow_destroy=true
terraform destroy -var allow_destroy=true
```
