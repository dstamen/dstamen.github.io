# everpure-azure-opentofu

Deploys Everpure Cloud Azure Native storage with OpenTofu and the
[Everpure Azure provider](https://registry.terraform.io/providers/PureStorage-OpenConnect/everpure-azure/latest)
(`PureStorage-OpenConnect/everpure-azure` 1.0.0): a storage pool, a volume group and volume per VM,
and iSCSI connections to a new Linux and Windows VM.

This is the same config as the Terraform version, minus the console SSH user action, which
OpenTofu doesn't support.

## Prerequisites

- An existing **Everpure Cloud Reservation** in the region you deploy to
- The `PureStorage.Block` resource provider registered on the subscription
- A subnet delegated to `PureStorage.Block/storagePools` for the pool
- A subnet for the VMs that can reach the pool subnet (the VMs get private IPs only)
- OpenTofu 1.11 or newer, for ephemeral resources (tested on 1.13.9)
- The Azure CLI, logged in with `az login`

## Provider install

The provider isn't on the OpenTofu registry yet, so install it from a local mirror:

```bash
./setup-mirror.sh 1.0.0 ~/.terraform.d/tofu-mirror
cp tofurc.example ~/.tofurc   # then fix the path inside
```

`setup-mirror.sh` downloads the release zip for your OS and CPU from GitHub and checks it
against the release `SHA256SUMS`.

## Usage

```bash
cp terraform.auto.tfvars.example terraform.auto.tfvars   # fill in your values
tofu init
tofu plan -out=tfplan
tofu apply tfplan   # pool create takes about 30 min
```

State is local (`backend.tf`). Swap in an `azurerm` backend to share it.

## What it builds

| Resource | File |
|---|---|
| `everpure_azure_storage_pool`, with platform console access | `pool.tf` |
| `everpure_azure_reservation` data source, so the pool gets the reservation ID by name | `reservation.tf` |
| Linux (Ubuntu 24.04) and Windows (Server 2022) VMs | `vm.tf` |
| `everpure_azure_volume_group` per VM, with an optional snapshot schedule | `volume_group.tf` |
| `everpure_azure_volume` `data1` per VM | `volume.tf` |
| `everpure_azure_virtual_machine_connection` per VM | `vm_connection.tf` |
| On-demand console activation credentials | `console.tf` |

A volume added to a volume group that a VM is already connected to needs
`iscsiadm -m session --rescan` on the guest before it shows up.

Snapshots (a manual snapshot, a volume restored from it and a cloned volume group) are in
`snapshot`, which OpenTofu ignores. Rename it to `snapshot.tf` to turn them on, and set
`snapshot_frequency` for a schedule.

## Console

The console is only reachable from inside the VNet, so SSH to a VM there and then to the
management IP in the `console` output. Temporary credentials for the default console user are
off by default, because every request invalidates the previous one:

```bash
tofu apply -var console_credentials=true   # writes .console-creds (0600, gitignored)
```

## Teardown

On Windows, take the Pure disks offline first, or the VM connection can't log out its iSCSI
sessions:

```powershell
Get-Disk | Where FriendlyName -like 'PURE*' | Set-Disk -IsOffline $true
```

Volume groups and volumes default to `deletion_protection = true` and soft-delete on destroy,
and a soft-deleted volume group or volume blocks the pool delete. Turn protection off first:

```bash
tofu apply -var allow_destroy=true
tofu destroy -var allow_destroy=true
```
