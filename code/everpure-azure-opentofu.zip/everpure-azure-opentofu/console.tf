# Platform console access. The platform_console block on the pool opens the
# console; this file is how you log in.

# --- SSH user ---------------------------------------------------------------
# Terraform creates the console SSH user with an action. OpenTofu has no action
# blocks, so create the user in the portal, or log in with the temporary
# credentials below. The console is only reachable from the VNet.

# --- Temporary credentials --------------------------------------------------
# Every open of the ephemeral resource issues a new password and invalidates
# the last one, so it's off by default and normal plans never touch it:
#   tofu apply -var console_credentials=true
# Writes username, password and expiry to .console-creds (0600, gitignored).

ephemeral "everpure_azure_platform_console_activation_credentials" "this" {
  count           = var.console_credentials ? 1 : 0
  storage_pool_id = everpure_azure_storage_pool.pool.id
}

resource "terraform_data" "console_creds" {
  count            = var.console_credentials ? 1 : 0
  triggers_replace = plantimestamp()

  # The password goes through the environment, never the command line.
  provisioner "local-exec" {
    command = "umask 077 && printf 'username=%s\\npassword=%s\\nexpires_at=%s\\n' \"$U\" \"$P\" \"$E\" > .console-creds"
    environment = {
      U = ephemeral.everpure_azure_platform_console_activation_credentials.this[0].username
      P = ephemeral.everpure_azure_platform_console_activation_credentials.this[0].password
      E = ephemeral.everpure_azure_platform_console_activation_credentials.this[0].expires_at
    }
  }
}

output "console" {
  value = {
    default_username = try(everpure_azure_storage_pool.pool.platform_console[0].default_username, null)
    management_ip    = try(everpure_azure_storage_pool.pool.platform_console[0].subnet[0].management_ip_address, null)
  }
}
