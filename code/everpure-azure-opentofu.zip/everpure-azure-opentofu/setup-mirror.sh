#!/usr/bin/env bash
# Downloads the Everpure Azure provider from its GitHub release into a local
# filesystem mirror for OpenTofu, and checks it against the release SHA256SUMS.
# Usage: ./setup-mirror.sh [version] [mirror dir]
set -euo pipefail
VERSION="${1:-1.0.0}"
MIRROR="${2:-$HOME/.terraform.d/tofu-mirror}"
OS="$(uname -s | tr '[:upper:]' '[:lower:]')"
case "$(uname -m)" in
  x86_64|amd64) ARCH=amd64 ;;
  arm64|aarch64) ARCH=arm64 ;;
  *) echo "unsupported arch $(uname -m)"; exit 1 ;;
esac
BASE="https://github.com/PureStorage-OpenConnect/terraform-provider-everpure-azure/releases/download/v${VERSION}"
ZIP="terraform-provider-everpure-azure_${VERSION}_${OS}_${ARCH}.zip"
DEST="$MIRROR/registry.opentofu.org/purestorage-openconnect/everpure-azure"
mkdir -p "$DEST"
curl -fsSL -o "$DEST/$ZIP" "$BASE/$ZIP"
curl -fsSL "$BASE/terraform-provider-everpure-azure_${VERSION}_SHA256SUMS" | grep " $ZIP\$" > "$DEST/SHA256SUMS.$ZIP"
(cd "$DEST" && shasum -a 256 -c "SHA256SUMS.$ZIP") && rm "$DEST/SHA256SUMS.$ZIP"
echo "mirror ready: $DEST/$ZIP"
