terraform {
  # Local state. Swap for a backend "azurerm" {} block to share state.
  backend "local" {}
}
