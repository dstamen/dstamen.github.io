# Scoped narrowly to the pool and the VMSS -- not the whole subscription.
# VM Contributor on the VMSS is needed because the Function pushes the
# vendor MountIscsiLinux extension onto a specific instance via ARM.

resource "azurerm_role_assignment" "orch_storage_pool" {
  scope                = data.azapi_resource.storage_pool.id
  role_definition_name = "Contributor"
  principal_id         = azurerm_linux_function_app.orchestrator.identity[0].principal_id
}

resource "azurerm_role_assignment" "orch_vmss" {
  scope                = azurerm_linux_virtual_machine_scale_set.lab.id
  role_definition_name = "Virtual Machine Contributor"
  principal_id         = azurerm_linux_function_app.orchestrator.identity[0].principal_id
}
