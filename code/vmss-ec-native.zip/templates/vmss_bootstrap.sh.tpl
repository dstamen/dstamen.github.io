#!/bin/bash
set -euo pipefail

apt-get update -y
apt-get install -y jq multipath-tools

IMDS="http://169.254.169.254/metadata"
FUNC_URL="${func_base_url}"
SECRET="${shared_secret}"

META=$(curl -s -H "Metadata:true" "$IMDS/instance?api-version=2021-02-01")
VMID=$(echo "$META" | jq -r '.compute.vmId')
RESOURCE_ID=$(echo "$META" | jq -r '.compute.resourceId')
INSTANCE_ID=$(basename "$RESOURCE_ID")
# Scheduled Events' Resources array names VMs by their ARM resource name
# (compute.name, e.g. "myvmss_19"), not the OS hostname ("myvmss000019")
# -- those are two different strings, and matching against hostname here
# means the filter below never matches anything.
SELF_NAME=$(echo "$META" | jq -r '.compute.name')
echo "$VMID" > /var/log/ec-vmid

# This creates the VolumeGroup/Volume and pushes the vendor MountIscsiLinux
# extension onto this instance via ARM. The extension only establishes the
# iSCSI sessions and lets multipathd claim the LUN -- it does not create a
# filesystem or mount it anywhere. It also reboots the instance to apply
# (settings.reboot = true), which kills any nohup background process, so
# the agent below runs as a real systemd service instead of a cloud-init
# background job, and picks up after the reboot on its own.
curl -s -X POST -H "x-shared-secret: $SECRET" \
  "$FUNC_URL/api/provision?vmId=$VMID&instanceId=$INSTANCE_ID" \
  > /var/log/ec-provision.json

cat > /usr/local/bin/ec-agent.sh << EOS
#!/bin/bash
IMDS="http://169.254.169.254/metadata"
FUNC_URL="$FUNC_URL"
SECRET="$SECRET"
VMID="$VMID"
SELF="$SELF_NAME"
MOUNTPOINT=/mnt/ecvol
mkdir -p "\$MOUNTPOINT"

while true; do
  if ! mountpoint -q "\$MOUNTPOINT"; then
    MPATH_DEV=\$(multipath -ll 2>/dev/null | awk '/PURE,FlashArray/{print \$1; exit}')
    if [ -n "\$MPATH_DEV" ]; then
      DEV="/dev/mapper/\$MPATH_DEV"
      blkid "\$DEV" >/dev/null 2>&1 || mkfs.ext4 -F "\$DEV"
      mount "\$DEV" "\$MOUNTPOINT"
    fi
  fi

  # Scheduled Events on a VMSS can list events for OTHER instances in the
  # same set too -- each event's Resources array says which VM it's
  # actually for. Skipping that check means every instance reacts to
  # every sibling's termination, deleting its own still-live volume.
  EVENTS=\$(curl -s -H "Metadata:true" "\$IMDS/scheduledevents?api-version=2020-07-01")
  EVENTIDS=\$(echo "\$EVENTS" | jq -r --arg self "\$SELF" \\
    '.Events[] | select(.EventType=="Terminate" and (.Resources | index(\$self) != null)) | .EventId')
  if [ -n "\$EVENTIDS" ]; then
    curl -s -X POST -H "x-shared-secret: \$SECRET" "\$FUNC_URL/api/deprovision?vmId=\$VMID" >> /var/log/ec-deprovision.json
    for EID in \$EVENTIDS; do
      curl -s -X POST -H "Metadata:true" -H "Content-Type: application/json" \\
        -d "{\\"StartRequests\\":[{\\"EventId\\":\\"\$EID\\"}]}" "\$IMDS/scheduledevents?api-version=2020-07-01" >/dev/null
    done
    exit 0
  fi

  sleep 5
done
EOS
chmod +x /usr/local/bin/ec-agent.sh

cat > /etc/systemd/system/ec-agent.service << 'EOF'
[Unit]
Description=EC native volume mount + termination watcher
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/ec-agent.sh
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now ec-agent.service
