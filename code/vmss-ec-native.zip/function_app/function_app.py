import logging
import os
import time

import azure.functions as func
import requests
from azure.identity import DefaultAzureCredential

app = func.FunctionApp()

ARM = "https://management.azure.com"
STORAGE_POOL_ID = os.environ["STORAGE_POOL_ID"]
LOCATION = os.environ["LOCATION"]
VG_API = os.environ["VOLUME_GROUP_API_VERSION"]
VOL_API = os.environ["VOLUME_API_VERSION"]
MOUNT_API = os.environ["MOUNT_DATA_API_VERSION"]
VOL_SIZE_BYTES = int(os.environ["VOL_SIZE_BYTES"])
VMSS_NAME = os.environ["VMSS_NAME"]
VMSS_ID = os.environ["VMSS_ID"]
SHARED_SECRET = os.environ["SHARED_SECRET"]

_credential = DefaultAzureCredential()


def _token() -> str:
    return _credential.get_token(f"{ARM}/.default").token


def _headers() -> dict:
    return {"Authorization": f"Bearer {_token()}", "Content-Type": "application/json"}


def _wait_succeeded(url: str, api_version: str, attempts: int = 18, delay: int = 5) -> dict:
    for _ in range(attempts):
        resp = requests.get(url, params={"api-version": api_version}, headers=_headers())
        if resp.status_code == 404:
            time.sleep(delay)
            continue
        resp.raise_for_status()
        body = resp.json()
        props = body.get("properties", {})
        if "provisioningState" not in props:
            # Volumes don't report a provisioningState at all -- creation is
            # synchronous, so a 200 with a body (e.g. a serialNumber) means done.
            return body
        state = props["provisioningState"]
        if state == "Succeeded":
            return body
        if state == "Failed":
            raise RuntimeError(f"{url} provisioning failed: {body}")
        time.sleep(delay)
    raise TimeoutError(f"{url} did not reach Succeeded in time")


def _names(vm_id: str) -> tuple[str, str]:
    # vm_id is the instance's own IMDS compute.vmId (a GUID) -- short and
    # unique per instance for the life of that instance, so it works fine as
    # a naming key even though it isn't the ARM-path numeric instanceId.
    key = vm_id.replace("-", "")[:12]
    return f"vg-{VMSS_NAME}-{key}", f"vol-{VMSS_NAME}-{key}"


def _authorized(req: func.HttpRequest) -> bool:
    return req.headers.get("x-shared-secret") == SHARED_SECRET


def _exists(url: str, api_version: str) -> bool:
    resp = requests.get(url, params={"api-version": api_version}, headers=_headers())
    return resp.status_code == 200


def _create_volume_group_and_volume(vm_id: str) -> dict:
    vg_name, vol_name = _names(vm_id)
    vg_url = f"{ARM}{STORAGE_POOL_ID}/volumeGroups/{vg_name}"

    # The RP rejects PUT on a resource that already exists (400
    # ResourceCreationValidateFailed), so this has to be get-or-create, not
    # a blind PUT -- a retried/duplicate boot call must not fail here.
    if not _exists(vg_url, VG_API):
        put = requests.put(
            vg_url,
            params={"api-version": VG_API},
            headers=_headers(),
            json={"location": LOCATION, "properties": {"performanceParameters": {}}},
        )
        if put.status_code not in (200, 201):
            put.raise_for_status()
    _wait_succeeded(vg_url, VG_API)

    vol_url = f"{vg_url}/volumes/{vol_name}"
    if not _exists(vol_url, VOL_API):
        put = requests.put(
            vol_url,
            params={"api-version": VOL_API},
            headers=_headers(),
            json={"properties": {"provisionedSize": VOL_SIZE_BYTES}},
        )
        if put.status_code not in (200, 201):
            put.raise_for_status()
    _wait_succeeded(vol_url, VOL_API)

    conn = requests.post(
        f"{vg_url}/listConnectionParameters",
        params={"api-version": MOUNT_API},
        headers=_headers(),
    )
    conn.raise_for_status()
    return conn.json()


def _mount_on_instance(instance_id: str, endpoints: list[dict]) -> None:
    ext_url = f"{ARM}{VMSS_ID}/virtualMachines/{instance_id}/extensions/MountIscsiLinux-deploy"
    targets = [{"ip": e["ip"], "port": 3260, "iqn": e["iqn"]} for e in endpoints]
    body = {
        "properties": {
            "publisher": "PureStorage.Extensions",
            "type": "MountIscsiLinux",
            "typeHandlerVersion": "1.3",
            "autoUpgradeMinorVersion": True,
            "settings": {
                "targets": targets,
                "replaceTargets": False,
                "sessionCount": 2,
                "reboot": False,  # Linux iscsid doesn't need a restart to pick up new targets; that's a Windows-only requirement
            },
        }
    }
    put = requests.put(ext_url, params={"api-version": "2024-07-01"}, headers=_headers(), json=body)
    if put.status_code not in (200, 201, 202):
        put.raise_for_status()
    logging.info("Mount extension submitted for instance %s: %s", instance_id, put.status_code)


def _delete_volume_and_group(vm_id: str) -> None:
    vg_name, vol_name = _names(vm_id)
    vg_url = f"{ARM}{STORAGE_POOL_ID}/volumeGroups/{vg_name}"
    vol_url = f"{vg_url}/volumes/{vol_name}"

    resp = requests.delete(vol_url, params={"api-version": VOL_API}, headers=_headers())
    if resp.status_code not in (200, 202, 204, 404):
        resp.raise_for_status()

    resp = requests.delete(vg_url, params={"api-version": VG_API}, headers=_headers())
    if resp.status_code not in (200, 202, 204, 404):
        resp.raise_for_status()

    logging.info("Deleted volume %s and volume group %s", vol_name, vg_name)


@app.function_name(name="provision")
@app.route(route="provision", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
def provision(req: func.HttpRequest) -> func.HttpResponse:
    if not _authorized(req):
        return func.HttpResponse("unauthorized", status_code=401)

    vm_id = req.params.get("vmId")
    instance_id = req.params.get("instanceId")
    if not vm_id or not instance_id:
        return func.HttpResponse("missing vmId or instanceId", status_code=400)

    logging.info("Provisioning volume for vmId=%s instanceId=%s", vm_id, instance_id)
    try:
        conn_params = _create_volume_group_and_volume(vm_id)
        endpoints = conn_params.get("iscsi", {}).get("endpoints", [])
        if not endpoints:
            raise RuntimeError(f"no iSCSI endpoints returned: {conn_params}")
        _mount_on_instance(instance_id, endpoints)
    except Exception as exc:
        logging.exception("Provisioning failed for vmId=%s", vm_id)
        return func.HttpResponse(f"provisioning failed: {exc}", status_code=500)

    return func.HttpResponse("ok", status_code=200)


@app.function_name(name="deprovision")
@app.route(route="deprovision", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
def deprovision(req: func.HttpRequest) -> func.HttpResponse:
    if not _authorized(req):
        return func.HttpResponse("unauthorized", status_code=401)

    vm_id = req.params.get("vmId")
    if not vm_id:
        return func.HttpResponse("missing vmId", status_code=400)

    logging.info("Deprovisioning volume for vmId=%s", vm_id)
    try:
        _delete_volume_and_group(vm_id)
    except Exception as exc:
        logging.exception("Deprovisioning failed for vmId=%s", vm_id)
        return func.HttpResponse(f"deprovisioning failed: {exc}", status_code=500)

    return func.HttpResponse("ok", status_code=200)
