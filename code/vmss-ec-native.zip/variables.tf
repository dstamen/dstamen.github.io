variable "subscription_id" {
  type        = string
  description = "Azure subscription ID"
}

variable "location" {
  type        = string
  description = "Azure region (e.g. eastus)"
}

variable "resource_group" {
  type        = string
  description = "Resource group for the VMSS and Function App -- keep this dedicated so it's easy to tear the whole lab down"
}

variable "vnet_resource_group" {
  type        = string
  description = "Resource group of the existing VNet the VMSS attaches to"
}

variable "vnet_name" {
  type        = string
  description = "Existing VNet name"
}

variable "subnet_name" {
  type        = string
  description = "Existing subnet name -- must already be able to reach the storage pool's iSCSI network"
}

variable "storage_pool_resource_group" {
  type        = string
  description = "Resource group of the existing EC native StoragePool"
}

variable "storage_pool_name" {
  type        = string
  description = "Name of the existing EC native StoragePool new VolumeGroups/Volumes get created underneath"
}

variable "vmss_name" {
  type        = string
  description = "Name for the VMSS (also used to derive the Function App, storage account, and service plan names)"
}

variable "vm_size" {
  type    = string
  default = "Standard_B2s"
}

variable "instance_count" {
  type        = number
  default     = 0
  description = "Start at 0 -- scale out manually to exercise the create path"
}

variable "admin_username" {
  type    = string
  default = "azureuser"
}

variable "admin_ssh_public_key" {
  type        = string
  description = "SSH public key content for the VMSS admin user"
}

variable "vol_size_bytes" {
  type        = number
  default     = 32212254720 # 30 GiB
  description = "Per-instance volume size"
}

variable "tags" {
  type        = map(string)
  description = "Tags to apply to all resources"
  default     = {}
}
