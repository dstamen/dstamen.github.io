data "azurerm_resource_group" "lab" {
  name = var.resource_group
}

data "azurerm_virtual_network" "core" {
  name                = var.vnet_name
  resource_group_name = var.vnet_resource_group
}

data "azurerm_subnet" "default" {
  name                 = var.subnet_name
  virtual_network_name = data.azurerm_virtual_network.core.name
  resource_group_name  = var.vnet_resource_group
}

# Existing EC native StoragePool we hang per-instance VolumeGroups/Volumes off of.
data "azapi_resource" "storage_pool" {
  type      = "PureStorage.Block/storagePools@2024-11-01-preview"
  name      = var.storage_pool_name
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.storage_pool_resource_group}"
}
