resource "random_string" "sa_suffix" {
  length  = 6
  special = false
  upper   = false
}

# Lab-only auth: instances present this on the provision/deprovision calls.
# Good enough for a throwaway RG; a real deployment would use the VMSS's own
# managed identity against Easy Auth / AAD instead of a shared secret baked
# into custom_data.
resource "random_password" "shared_secret" {
  length  = 32
  special = false
}

resource "azurerm_storage_account" "func" {
  name                     = "stvmssec${random_string.sa_suffix.result}"
  resource_group_name      = data.azurerm_resource_group.lab.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = var.tags
}

resource "azurerm_service_plan" "func" {
  name                = "${var.vmss_name}-orch-plan"
  resource_group_name = data.azurerm_resource_group.lab.name
  location            = var.location
  os_type             = "Linux"
  sku_name            = "Y1" # Consumption
  tags                = var.tags
}

resource "azurerm_linux_function_app" "orchestrator" {
  name                = "${var.vmss_name}-orch"
  resource_group_name = data.azurerm_resource_group.lab.name
  location            = var.location
  tags                = var.tags

  storage_account_name       = azurerm_storage_account.func.name
  storage_account_access_key = azurerm_storage_account.func.primary_access_key
  service_plan_id            = azurerm_service_plan.func.id

  identity {
    type = "SystemAssigned"
  }

  site_config {
    application_stack {
      python_version = "3.11"
    }
  }

  app_settings = {
    "FUNCTIONS_WORKER_RUNTIME"    = "python"
    "STORAGE_POOL_ID"             = data.azapi_resource.storage_pool.id
    "LOCATION"                    = var.location
    "VOLUME_GROUP_API_VERSION"    = "2026-01-01-preview"
    "VOLUME_API_VERSION"          = "2026-05-01-preview"
    "MOUNT_DATA_API_VERSION"      = "2026-05-01-preview"
    "VOL_SIZE_BYTES"              = tostring(var.vol_size_bytes)
    "VMSS_NAME"                   = var.vmss_name
    "VMSS_ID"                     = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${var.vmss_name}"
    "SHARED_SECRET"               = random_password.shared_secret.result
  }
}

output "function_app_name" {
  value = azurerm_linux_function_app.orchestrator.name
}

output "function_app_identity_principal_id" {
  value = azurerm_linux_function_app.orchestrator.identity[0].principal_id
}
