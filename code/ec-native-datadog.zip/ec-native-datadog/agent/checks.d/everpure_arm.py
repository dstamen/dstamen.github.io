"""Datadog custom Agent check: Everpure Cloud Azure Native usage and billing from ARM.

Finds storage pools across one or many subscriptions with Azure Resource Graph (or a plain
ARM list per subscription), then for every pool that provisioned successfully:
  GET  storagePools (via Resource Graph)      provisioned IOPS / bandwidth, platform console state
  POST storagePools/{name}/getHealthStatus    live capacity, DRR, IOPS and bandwidth usage, alerts
  POST reservations/{name}/getBillingStatus   billed capacity, overage, performance billing
  POST reservations/{name}/getBillingReport   per-property billing status (best effort, 500s today)

Auth on the Agent VM is the VM's managed identity via IMDS. Reader is NOT enough, the
health and billing calls are POST /action operations. Assign the custom role in
azure/everpure-metrics-reader-role.json on the resource groups holding pools and reservations.

Pools that failed or are still provisioning are skipped unless include_failed is set, so a
subscription full of failed test pools doesn't flood Datadog with dead series. Every metric is
tagged subscription_name (falls back to the id when the identity can't read the subscription).

Run standalone for testing (uses your az CLI login):
  python3 everpure_arm.py --subscription <sub-id>          # one subscription
  python3 everpure_arm.py --subscription <a> --subscription <b>
  python3 everpure_arm.py                                  # every subscription you can read
"""

import json
import re
import subprocess
import sys
import time

ARM = "https://management.azure.com"
DEFAULT_API_VERSION = "2026-05-01-preview"
GRAPH_API_VERSION = "2022-10-01"
LIVE_STATES = ("Succeeded", "Updating")

# Resource Graph keeps the ARM property casing, so the rows look like a storagePools GET.
# The left outer join adds the subscription display name when the identity can read it.
POOLS_QUERY = """
resources
| where type =~ 'purestorage.block/storagepools'
| join kind=leftouter (
    resourcecontainers
    | where type =~ 'microsoft.resources/subscriptions'
    | project subscriptionId, subscriptionName = name
  ) on subscriptionId
| project id, name, location, tags, properties, subscriptionId, subscriptionName
"""
IMDS = "http://169.254.169.254/metadata/identity/oauth2/token"

try:
    from datadog_checks.base import AgentCheck
except ImportError:  # standalone mode
    AgentCheck = object


def snake(name):
    return re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()


def tag_value(text):
    """Datadog turns spaces and brackets into underscores; do it readably instead.
    'My Azure (Prod)' -> 'my-azure-prod'."""
    return re.sub(r"[^a-z0-9_./-]+", "-", text.lower()).strip("-")


def parse_id(resource_id):
    parts = resource_id.strip("/").split("/")
    out = {}
    for i in range(0, len(parts) - 1, 2):
        out[parts[i].lower()] = parts[i + 1]
    return out


def pool_metrics(pool, health):
    """Return [(metric, value)] for one pool. Pure function, easy to test."""
    props = pool.get("properties", {})
    out = []
    if props.get("provisionedIops") is not None:
        out.append(("pool.provisioned_iops", props["provisionedIops"]))
    if props.get("provisionedBandwidthMbPerSec") is not None:
        out.append(("pool.provisioned_bandwidth_mbps", props["provisionedBandwidthMbPerSec"]))
    out.append(("pool.platform_console_enabled", 1 if props.get("platformConsoleSettings", {}).get("enabled") else 0))
    out.append(("pool.provisioning_succeeded", 1 if props.get("provisioningState") == "Succeeded" else 0))

    if not health:
        return out
    h = health.get("health", {})
    for key in ("iopsUsage", "bandwidthUsage"):
        base = "pool.iops" if key == "iopsUsage" else "pool.bandwidth_bytes"
        for sub in ("current", "provisioned", "max"):
            if h.get(key, {}).get(sub) is not None:
                out.append((base + "." + sub, h[key][sub]))
        cur, prov = h.get(key, {}).get("current"), h.get(key, {}).get("provisioned")
        if cur is not None and prov:
            out.append((base + ".pct_of_provisioned", 100.0 * cur / prov))
    for k, v in h.get("space", {}).items():
        out.append(("pool.space_bytes." + snake(k), v))
    if h.get("dataReductionRatio") is not None:
        out.append(("pool.data_reduction_ratio", h["dataReductionRatio"]))
        used = h.get("space", {}).get("totalUsed")
        if used is not None:
            # logical (pre-reduction) capacity estimate, so a fleet DRR can be capacity-weighted:
            # sum(logical) / sum(used). Averaging per-pool ratios lets a near-empty pool dominate.
            out.append(("pool.space_bytes.logical_estimate", h["dataReductionRatio"] * used))
    if h.get("estimatedMaxCapacity") is not None:
        out.append(("pool.estimated_max_capacity_bytes", h["estimatedMaxCapacity"]))
    if h.get("usedCapacityPercentage") is not None:
        # ARM reports this already as a percent (0.00055 = 0.00055 %)
        out.append(("pool.used_capacity_percent", h["usedCapacityPercentage"]))
    out.append(("pool.alerts", len(health.get("alerts", []))))
    return out


def billing_status_metrics(status):
    """Every numeric field in getBillingStatus becomes reservation.billing.<snake_name>."""
    out = []
    for k, v in status.items():
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            out.append(("reservation.billing." + snake(k), v))
    billed = status.get("totalUsedCapacityBilled")
    reported = status.get("totalUsedCapacityReported")
    if billed and reported is not None:
        # how much of the billed capacity is real data vs minimums and rounding
        out.append(("reservation.billing.used_vs_billed_percent", 100.0 * reported / billed))
    return out


def billing_report_metrics(report):
    out = []
    for p in report.get("billingUsageProperties", []) or []:
        try:
            out.append(("reservation.billing_report." + snake(p["propertyId"]), float(p["currentValue"])))
        except (KeyError, TypeError, ValueError):
            continue
    return out


class ArmClient(object):
    def __init__(self, token_fn, http_get, http_post, api_version):
        self._token_fn = token_fn
        self._get = http_get
        self._post = http_post
        self.api_version = api_version

    def _url(self, path):
        sep = "&" if "?" in path else "?"
        return ARM + path + sep + "api-version=" + self.api_version

    def _headers(self):
        return {"Authorization": "Bearer " + self._token_fn(), "Content-Type": "application/json"}

    def get(self, path):
        return self._get(self._url(path), self._headers())

    def post(self, path, body=None, api_version=None):
        url = self._url(path) if api_version is None else ARM + path + "?api-version=" + api_version
        return self._post(url, self._headers(), body)

    def list_pools(self, subscription_id):
        """Plain ARM list for one subscription (discovery: arm)."""
        pools, path = [], "/subscriptions/%s/providers/PureStorage.Block/storagePools" % subscription_id
        url = self._url(path)
        while url:
            page = self._get(url, self._headers())
            pools.extend(page.get("value", []))
            url = page.get("nextLink")
        return pools

    def graph_pools(self, subscription_ids=None, management_groups=None):
        """Every pool the identity can read, in any subscription, via Resource Graph."""
        body = {"query": POOLS_QUERY, "options": {"$top": 1000, "resultFormat": "objectArray"}}
        if subscription_ids:
            body["subscriptions"] = list(subscription_ids)
        if management_groups:
            body["managementGroups"] = list(management_groups)
        pools = []
        while True:
            page = self.post("/providers/Microsoft.ResourceGraph/resources", body, GRAPH_API_VERSION)
            pools.extend(page.get("data", []))
            token = page.get("$skipToken")
            if not token:
                return pools
            body["options"]["$skipToken"] = token


def find_pools(arm, subscription_ids=None, discovery="resource_graph", management_groups=None):
    if discovery == "arm":
        if not subscription_ids:
            raise ValueError("discovery: arm needs subscription_id or subscription_ids")
        return [p for sub in subscription_ids for p in arm.list_pools(sub)]
    return arm.graph_pools(subscription_ids, management_groups)


def collect(arm, subscription_ids=None, resource_groups=None, pool_names=None, emit=None, svc=None,
            discovery="resource_graph", management_groups=None, include_failed=False):
    """Walk pools and reservations and hand each metric to emit(name, value, tags)."""
    if isinstance(subscription_ids, str):
        subscription_ids = [subscription_ids]
    rg_filter = {r.lower() for r in (resource_groups or [])}
    name_filter = {n.lower() for n in (pool_names or [])}
    reservations = {}  # lower-cased id -> (id, name); many pools can share one reservation
    sub_names = {}

    for pool in find_pools(arm, subscription_ids, discovery, management_groups):
        ids = parse_id(pool["id"])
        rg = ids.get("resourcegroups", "")
        sub_id = ids.get("subscriptions", "").lower()
        if rg_filter and rg.lower() not in rg_filter:
            continue
        if name_filter and pool["name"].lower() not in name_filter:
            continue
        props = pool.get("properties") or {}
        if not include_failed and props.get("provisioningState") not in LIVE_STATES:
            continue
        sub_name = tag_value(pool.get("subscriptionName") or sub_id)
        sub_names[sub_id] = sub_name
        res_id = props.get("reservationResourceId", "")
        res_name = parse_id(res_id).get("reservations", "") if res_id else ""
        tags = [
            "storage_pool:" + pool["name"],
            "resource_group:" + rg.lower(),
            "subscription_id:" + sub_id,
            "subscription_name:" + sub_name,
            "azure_region:" + pool.get("location", ""),
            "availability_zone:" + str(props.get("availabilityZone", "")),
            "reservation:" + res_name,
        ] + ["azure_tag_%s:%s" % (k, v) for k, v in (pool.get("tags") or {}).items()]

        health = None
        if props.get("provisioningState") in LIVE_STATES:
            try:
                health = arm.post(pool["id"] + "/getHealthStatus")
                svc("pool.health_api", 0, tags, None)
            except Exception as e:  # keep going for the other pools
                svc("pool.health_api", 2, tags, str(e)[:200])
        for name, value in pool_metrics(pool, health):
            emit(name, value, tags)
        if res_id:
            reservations.setdefault(res_id.lower(), (res_id, res_name))

    for res_id, res_name in reservations.values():
        ids = parse_id(res_id)
        res_sub = ids.get("subscriptions", "").lower()
        tags = [
            "reservation:" + res_name,
            "resource_group:" + ids.get("resourcegroups", "").lower(),
            "subscription_id:" + res_sub,
            "subscription_name:" + sub_names.get(res_sub, res_sub),
        ]
        try:
            for name, value in billing_status_metrics(arm.post(res_id + "/getBillingStatus")):
                emit(name, value, tags)
            svc("reservation.billing_status_api", 0, tags, None)
        except Exception as e:
            svc("reservation.billing_status_api", 2, tags, str(e)[:200])
        try:
            for name, value in billing_report_metrics(arm.post(res_id + "/getBillingReport")):
                emit(name, value, tags)
            svc("reservation.billing_report_api", 0, tags, None)
        except Exception as e:
            # known to return 500 on 2026-05-01-preview; warn rather than page
            svc("reservation.billing_report_api", 1, tags, str(e)[:200])


class EverpureArmCheck(AgentCheck):
    __NAMESPACE__ = "everpure"

    def __init__(self, name, init_config, instances):
        super(EverpureArmCheck, self).__init__(name, init_config, instances)
        self._token = None
        self._token_exp = 0

    def _imds_token(self):
        if self._token and time.time() < self._token_exp - 300:
            return self._token
        params = {"api-version": "2018-02-01", "resource": ARM + "/"}
        if self.instance.get("client_id"):
            params["client_id"] = self.instance["client_id"]
        r = self.http.get(IMDS, params=params, headers={"Metadata": "true"}, persist=False)
        r.raise_for_status()
        body = r.json()
        self._token, self._token_exp = body["access_token"], int(body["expires_on"])
        return self._token

    def _http_get(self, url, headers):
        r = self.http.get(url, headers=headers, persist=False)
        r.raise_for_status()
        return r.json()

    def _http_post(self, url, headers, body=None):
        r = self.http.post(url, headers=headers, data=json.dumps(body or {}), persist=False)
        r.raise_for_status()
        return r.json() if r.content else {}

    def check(self, _):
        inst = self.instance
        # subscription_id (one) and subscription_ids (list) both work; neither means every
        # subscription the identity can read (Resource Graph only)
        subs = list(inst.get("subscription_ids") or [])
        if inst.get("subscription_id"):
            subs.append(inst["subscription_id"])
        extra = inst.get("tags", [])
        arm = ArmClient(self._imds_token, self._http_get, self._http_post,
                        inst.get("api_version", DEFAULT_API_VERSION))
        collect(
            arm, subs,
            resource_groups=inst.get("resource_groups"),
            pool_names=inst.get("storage_pools"),
            discovery=inst.get("discovery", "resource_graph"),
            management_groups=inst.get("management_groups"),
            include_failed=inst.get("include_failed", False),
            emit=lambda n, v, t: self.gauge(n, v, tags=t + extra),
            svc=lambda n, s, t, m: self.service_check(n, s, tags=t + extra, message=m),
        )


# ---------------------------------------------------------------- standalone
def _az_token():
    return subprocess.check_output(
        ["az", "account", "get-access-token", "--resource", ARM + "/", "--query", "accessToken", "-o", "tsv"]
    ).decode().strip()


def _urllib(method):
    import urllib.request

    def call(url, headers, body=None):
        data = json.dumps(body or {}).encode() if method == "POST" else None
        req = urllib.request.Request(url, headers=headers, method=method, data=data)
        with urllib.request.urlopen(req, timeout=60) as r:
            body = r.read()
            return json.loads(body) if body else {}
    return call


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--subscription", action="append", help="repeat for several; omit for all you can read")
    ap.add_argument("--management-group", action="append")
    ap.add_argument("--resource-group", action="append")
    ap.add_argument("--pool", action="append")
    ap.add_argument("--discovery", choices=["resource_graph", "arm"], default="resource_graph")
    ap.add_argument("--include-failed", action="store_true")
    ap.add_argument("--api-version", default=DEFAULT_API_VERSION)
    a = ap.parse_args()
    tok = {}

    def token():
        if "t" not in tok:
            tok["t"] = _az_token()
        return tok["t"]

    arm = ArmClient(token, _urllib("GET"), _urllib("POST"), a.api_version)
    status = {0: "OK", 1: "WARNING", 2: "CRITICAL"}
    collect(
        arm, a.subscription, a.resource_group, a.pool,
        discovery=a.discovery, management_groups=a.management_group, include_failed=a.include_failed,
        emit=lambda n, v, t: print("everpure.%-52s %18s  %s" % (n, v, ",".join(x for x in t if not x.startswith("azure_tag_")))),
        svc=lambda n, s, t, m: print("SERVICE_CHECK everpure.%s %s %s" % (n, status[s], (m or "")[:120]), file=sys.stderr),
    )
