#!/usr/bin/env bash
# Install the Datadog Agent on a Linux VM inside the storage pool's VNet and configure:
#   - purefa (OpenMetrics) check against each pool's platform console
#   - everpure_arm custom check for ARM health / billing / usage
#
# Usage (on the VM, as root):
#   export DD_API_KEY=...            # Datadog API key
#   export DD_SITE=datadoghq.com     # or us3.datadoghq.com, us5..., datadoghq.eu
#   export AZ_SUBSCRIPTION_ID=<subscription-id>
#   export AZ_RESOURCE_GROUPS="my-pool-rg my-agent-rg"   # optional
#   export AZ_EXTRA_SUBSCRIPTION_IDS="<sub> <sub>"   # optional, more subscriptions for ARM-only pools
#   export AZ_MANAGEMENT_GROUPS="my-management-group"        # optional, every subscription under these
#   ./install.sh pools.csv
#
# pools.csv: name,mgmt_ip,api_token  (header row required, keep it out of git)
set -euo pipefail

POOLS_CSV=${1:-pools.csv}
HERE=$(cd "$(dirname "$0")" && pwd)
PUREFA_VERSION=${PUREFA_VERSION:-1.3.0}
: "${DD_API_KEY:?set DD_API_KEY}"
: "${DD_SITE:=datadoghq.com}"
: "${AZ_SUBSCRIPTION_ID:?set AZ_SUBSCRIPTION_ID}"
[ -f "$POOLS_CSV" ] || { echo "missing $POOLS_CSV"; exit 1; }

# 1. Agent
if ! command -v datadog-agent >/dev/null; then
  DD_API_KEY="$DD_API_KEY" DD_SITE="$DD_SITE" \
    bash -c "$(curl -fsSL https://install.datadoghq.com/scripts/install_script_agent7.sh)"
fi

# 2. purefa integration (community / integrations-extras)
sudo -u dd-agent datadog-agent integration install -t "datadog-purefa==${PUREFA_VERSION}" -r

# 3. purefa conf.yaml, one instance per metrics path per pool
CONF=/etc/datadog-agent/conf.d/purefa.d
mkdir -p "$CONF"
{
  echo "init_config:"
  echo "  timeout: 60"
  echo "instances:"
  tail -n +2 "$POOLS_CSV" | while IFS=, read -r name ip token; do
    [ -z "$name" ] && continue
    for path in array volumes hosts pods directories; do
      cat <<EOF
  - openmetrics_endpoint: https://${ip}/metrics/${path}?namespace=purefa
    min_collection_interval: 120
    tls_verify: false
    tls_ignore_warning: true
    empty_default_hostname: true
    rename_labels:
      host: fa_host
    headers:
      Authorization: Bearer ${token}
    tags:
      - cloud_provider:azure
      - platform:everpure_cloud_azure_native
      - storage_pool:${name}
      - fa_array_name:${name}
      - metrics_path:${path}
EOF
      # purefa 1.3.0 doesn't map volume group metrics, so they'd be dropped
      if [ "$path" = volumes ]; then cat <<EOF
    extra_metrics:
      - purefa_volume_group_performance_throughput_iops: volume_group.performance_throughput_iops
      - purefa_volume_group_performance_bandwidth_bytes: volume_group.performance_bandwidth_bytes
      - purefa_volume_group_performance_latency_usec: volume_group.performance_latency_usec
      - purefa_volume_group_performance_average_bytes: volume_group.performance_average_bytes
      - purefa_volume_group_qos_iops_limit: volume_group.qos_iops_limit
EOF
      fi
    done
  done
} > "$CONF/conf.yaml"
chown dd-agent:dd-agent "$CONF/conf.yaml"
chmod 640 "$CONF/conf.yaml"

# 4. everpure_arm custom check
install -o dd-agent -g dd-agent -m 644 "$HERE/agent/checks.d/everpure_arm.py" /etc/datadog-agent/checks.d/everpure_arm.py
ARMCONF=/etc/datadog-agent/conf.d/everpure_arm.d
mkdir -p "$ARMCONF"
{
  echo "init_config:"
  echo "instances:"
  echo "  - subscription_ids:"
  for s in $AZ_SUBSCRIPTION_ID ${AZ_EXTRA_SUBSCRIPTION_IDS:-}; do echo "      - $s"; done
  if [ -n "${AZ_MANAGEMENT_GROUPS:-}" ]; then
    echo "    management_groups:"
    for mg in $AZ_MANAGEMENT_GROUPS; do echo "      - $mg"; done
  fi
  if [ -n "${AZ_RESOURCE_GROUPS:-}" ]; then
    echo "    resource_groups:"
    for rg in $AZ_RESOURCE_GROUPS; do echo "      - $rg"; done
  fi
  [ -n "${AZ_CLIENT_ID:-}" ] && echo "    client_id: ${AZ_CLIENT_ID}"
  echo "    min_collection_interval: 300"
  echo "    tags:"
  echo "      - cloud_provider:azure"
  echo "      - platform:everpure_cloud_azure_native"
} > "$ARMCONF/conf.yaml"
chown -R dd-agent:dd-agent "$ARMCONF"

# 5. restart and verify
systemctl restart datadog-agent
sleep 20
sudo -u dd-agent datadog-agent check purefa --check-rate 2>&1 | grep -E "Total Runs|Metric Samples|Error|error" | head -20 || true
sudo -u dd-agent datadog-agent check everpure_arm 2>&1 | grep -E "Total Runs|Metric Samples|Service Checks|Error|error" | head -20 || true
datadog-agent status 2>&1 | sed -n '/purefa/,/^$/p;/everpure_arm/,/^$/p' | head -60
