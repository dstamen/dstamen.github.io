# Everpure Cloud Azure Native + Datadog

Send Everpure Cloud Azure Native storage pool metrics to Datadog and build a dashboard.

Two data sources land in Datadog, both tagged `storage_pool:<name>`:

| Prefix | Source | What you get |
|---|---|---|
| `purefa.*` | Purity OpenMetrics on the pool's **platform console** (Datadog `purefa` integration) | array/volume/host/pod perf, latency, capacity by type, DRR |
| `everpure.*` | Azure ARM `getHealthStatus` + `getBillingStatus` (custom Agent check `everpure_arm`) | IOPS and bandwidth used vs provisioned vs max, pool capacity, alerts, billed vs used capacity, performance overage |

```
my-agent-vm (Datadog Agent, in the VNet)
  ├─ purefa check      ── https://<platform console mgmt IP>/metrics/{array,volumes,hosts,pods,directories}
  └─ everpure_arm check ── management.azure.com (VM managed identity)
           │
           └──► Datadog ──► "Everpure Cloud Azure Native" dashboard (Terraform)
```

## Prerequisites

- A storage pool with the platform console enabled (Azure portal > Storage Pool > Settings > Platform console)
- A Linux VM in the same VNet as the pool's delegated subnet. The management IP is private, so the Agent has to run inside the VNet.
- Datadog API key and an application key (for Terraform)
- az CLI and Terraform

## 1. Create a read-only API token on the pool

The OpenMetrics endpoint takes a bearer token issued to a local user. SSH to the platform console management IP as `cloudadmin` and create a read-only user:

```bash
pureadmin create --role readonly dd-metrics
```

Then log in as `dd-metrics` and create its token:

```bash
pureadmin create --api-token
```

To find the management IP, run:

```bash
az rest --method get --url "https://management.azure.com/subscriptions/<sub>/resourceGroups/<rg>/providers/PureStorage.Block/storagePools/<pool>?api-version=2026-05-01-preview" --query "properties.platformConsoleSettings.subnets[0].managementIpAddress" -o tsv
```

## 2. Give the Agent VM access to ARM

Reader is not enough. `getHealthStatus` and `getBillingStatus` are POST actions, so create the custom role and assign it to the VM's managed identity on the resource groups that hold the pools **and** the reservation:

```bash
az vm identity assign -g my-agent-rg -n my-agent-vm
az role definition create --role-definition azure/everpure-metrics-reader-role.json
PID=$(az vm show -g my-agent-rg -n my-agent-vm --query identity.principalId -o tsv)
for rg in my-pool-rg my-agent-rg my-core-rg; do
  az role assignment create --assignee-object-id $PID --assignee-principal-type ServicePrincipal \
    --role "Everpure Cloud Metrics Reader" --scope /subscriptions/<sub>/resourceGroups/$rg
done
```

## 3. Install the Agent and checks

Copy this folder to the VM, create `pools.csv` from `pools.csv.example` (it holds tokens, keep it out of git), then run:

```bash
export DD_API_KEY=<key>
export DD_SITE=datadoghq.com
export AZ_SUBSCRIPTION_ID=<sub>
export AZ_RESOURCE_GROUPS="my-pool-rg my-agent-rg"
sudo -E ./install.sh pools.csv
```

`install.sh` installs Agent 7, the `datadog-purefa` integration, writes both check configs and runs each check once so you can see metric counts.

## 4. Deploy the dashboard

```bash
cd terraform
export TF_VAR_datadog_api_key=<key> TF_VAR_datadog_app_key=<app key>
terraform init
terraform apply
```

It also writes `dashboard.json` if you want to import by hand (Dashboards > New Dashboard > Import JSON). Filter with the `storage_pool` and `reservation` template variables.

## More subscriptions (ARM-only pools)

Pools without a platform console, or in subscriptions the Agent VM can't reach on the network, still get the ARM side: usage vs provisioned, capacity, DRR, alerts and billing. `everpure_arm` finds pools with Azure Resource Graph, so one instance covers any number of subscriptions:

```yaml
instances:
  - subscription_ids: [<sub>, <sub>]   # or management_groups: [my-management-group], or neither for everything readable
```

With `install.sh`, set `AZ_EXTRA_SUBSCRIPTION_IDS` or `AZ_MANAGEMENT_GROUPS`. The VM identity needs the custom role in each of those subscriptions (or at the management group, after adding it to the role's `AssignableScopes`), plus wherever the pools' reservations live.

- Pools that failed or are still provisioning are skipped. `include_failed: true` reports them too.
- Every metric is tagged `subscription_name` (for example `another-subscription`). The name needs `Microsoft.Resources/subscriptions/read`, which is in the role JSON. Without it the tag falls back to the subscription id.
- Reservations shared by many pools are only called once per run.
- On the dashboard, **Fleet: All Pools (ARM)** lists every pool, and the `subscription` filter applies to the ARM and fleet widgets. The OpenMetrics sections stay empty for pools without a platform console.

## Testing the ARM side without an Agent

The custom check runs standalone off your az CLI login:

```bash
python3 agent/checks.d/everpure_arm.py --subscription <sub>                       # one subscription
python3 agent/checks.d/everpure_arm.py --subscription <a> --subscription <b>     # several
python3 agent/checks.d/everpure_arm.py --management-group my-management-group           # a management group
```

## Known issues

- `reservations/getBillingReport` returns HTTP 500 on every API version available in westus2 (2024-11-01, 2026-05-01-preview). The spec has a GA 2026-10-01 version that isn't rolled out to the region yet. The check keeps calling it and reports a WARNING service check `everpure.reservation.billing_report_api` until it starts working.
- Billed capacity includes the low-usage minimum. A nearly empty pool still bills about 30 TiB, so the Billing section shows **Headroom** (billed minus used) rather than a ratio.
- `usedCapacityPercentage` from ARM is already a percent (0.0005 means 0.0005%, not 0.05%).
