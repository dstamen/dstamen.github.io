# Everpure Cloud Azure Native dashboard for Datadog.
#
# Two data sources, both tagged storage_pool:<name>:
#   purefa.*     Purity OpenMetrics via the platform console (Datadog purefa integration)
#   everpure.*   ARM getHealthStatus / getBillingStatus via the everpure_arm custom check
#
# Tag values (dimension:reads_per_sec, space:unique, ...) are the native Purity
# OpenMetrics labels, the same ones the Observe dashboard was built on.
#
# To add a stat card: add an entry to local.overview_stats or local.arm_stats.

locals {
  # Both checks tag platform:everpure_cloud_azure_native. Pinning every query to it keeps other
  # FlashArrays reporting purefa.* into the same org out of the default (*) view.
  platform = "platform:everpure_cloud_azure_native"
  pool     = "$storage_pool,${local.platform}"
  res      = "$reservation,${local.platform}"
  # ARM metrics also carry subscription_name; purefa metrics don't, so only ARM widgets use it
  arm = "$storage_pool,$subscription,${local.platform}"

  byte_unit = { type = "canonical_unit", unit_name = "byte" }
  bps_unit  = { type = "canonical_unit", unit_name = "byte", per_unit_name = "second" }
  usec_unit = { type = "canonical_unit", unit_name = "microsecond" }
  pct_unit  = { type = "canonical_unit", unit_name = "percent" }
  iops_unit = { type = "canonical_unit", unit_name = "operation", per_unit_name = "second" }

  # ------------------------------------------------------------ Everpure brand
  # Datadog only takes hex on query_value conditional formats. Everything else uses
  # its named palettes: "orange" for the lead series, "gray" for comparison series.
  ash_gray = "#2D2A27"
  # purefa.* metrics carry ops/s in their Datadog metadata, which a card shows even with no
  # number_format. A zero-width custom_unit overrides it so the card shows just the number.
  no_unit     = "\u200b"
  pure_orange = "#FF7023"

  # trend series styles, in series order: read / current lead in orange, write / provisioned
  # in the brand's green family, the rest gray. Line style tells them apart in a legend-less glance.
  series_style = [
    { palette = "orange", line = "solid" },
    { palette = "green", line = "dashed" },
    { palette = "gray", line = "dotted" },
    { palette = "gray", line = "dashed" },
  ]

  # ------------------------------------------------------------ stat cards
  # hero = true renders the number in Pure Orange. One per section.
  overview_stats = [
    # Purity's virtual / total_physical lags ARM and the pool doesn't expose
    # purefa_array_space_data_reduction_ratio, so use the ARM value (same number Azure bills on)
    # capacity-weighted across pools: logical / physical. An average of per-pool ratios let a
    # near-empty pool report 189:1.
    { title = "Data Reduction", q = "sum:everpure.pool.space_bytes.logical_estimate{${local.pool}}", q2 = "sum:everpure.pool.space_bytes.total_used{${local.pool}}", formula = "q / q2", unit = null, custom_unit = ":1", precision = 1, hero = true },
    # tiny on a near-empty pool: autoscale off so it reads 0.008 % instead of 8.25e-3 %
    { title = "Utilization", q = "avg:purefa.array.space_utilization{${local.pool}}", unit = local.pct_unit, precision = 3, autoscale = false },
    { title = "Read IOPS", q = "avg:purefa.array.performance_throughput_iops{${local.pool},dimension:reads_per_sec}", unit = null, custom_unit = local.no_unit, precision = 1 },
    { title = "Write IOPS", q = "avg:purefa.array.performance_throughput_iops{${local.pool},dimension:writes_per_sec}", unit = null, custom_unit = local.no_unit, precision = 1 },
    { title = "Read Latency", q = "avg:purefa.array.performance_latency_usec{${local.pool},dimension:usec_per_read_op}", unit = local.usec_unit, precision = 0 },
    { title = "Write Latency", q = "avg:purefa.array.performance_latency_usec{${local.pool},dimension:usec_per_write_op}", unit = local.usec_unit, precision = 0 },
  ]

  # titles kept short so they fit a 2-column card without truncating
  arm_stats = [
    { title = "IOPS Used", q = "avg:everpure.pool.iops.pct_of_provisioned{${local.arm}}", unit = local.pct_unit, precision = 1, hero = true },
    { title = "Bandwidth Used", q = "avg:everpure.pool.bandwidth_bytes.pct_of_provisioned{${local.arm}}", unit = local.pct_unit, precision = 1 },
    { title = "Capacity Used", q = "avg:everpure.pool.used_capacity_percent{${local.arm}}", unit = local.pct_unit, precision = 3, autoscale = false },
    { title = "Used", q = "sum:everpure.pool.space_bytes.total_used{${local.arm}}", unit = local.byte_unit, precision = 2 },
    { title = "Max Capacity", q = "sum:everpure.pool.estimated_max_capacity_bytes{${local.arm}}", unit = local.byte_unit, precision = 0 },
    { title = "Open Alerts", q = "sum:everpure.pool.alerts{${local.arm}}", unit = null, precision = 0 },
  ]

  # TV top bar: absolute used next to provisioned, summed across the pools in the filter.
  # A percent alone doesn't say how big the pool is.
  tv_stats = [
    # IOPS short with one decimal (6.6k, 200k); bandwidth as the full MB/s number (523, 2848).
    # Datadog value cards can't show thousands separators.
    # Bandwidth is MB/s (MiB/s, as the Azure portal reports it).
    { title = "IOPS", q = "sum:everpure.pool.iops.current{${local.arm}}", unit = null, precision = 1 },
    { title = "IOPS Prov", q = "sum:everpure.pool.iops.provisioned{${local.arm}}", unit = null, precision = 1 },
    { title = "Bandwidth", q = "sum:everpure.pool.bandwidth_bytes.current{${local.arm}}", formula = "q / 1048576", unit = null, custom_unit = "MB/s", precision = 0, autoscale = false },
    { title = "BW Prov", q = "sum:everpure.pool.bandwidth_bytes.provisioned{${local.arm}}", formula = "q / 1048576", unit = null, custom_unit = "MB/s", precision = 0, autoscale = false },
  ]

  billing_stats = [
    { title = "Billed", q = "avg:everpure.reservation.billing.total_used_capacity_billed{${local.res}}", unit = local.byte_unit, precision = 2, hero = true },
    { title = "Actual Used", q = "avg:everpure.reservation.billing.total_used_capacity_reported{${local.res}}", unit = local.byte_unit, precision = 2 },
    # billed minus used: how much you can write before the bill grows
    { title = "Headroom", q = "avg:everpure.reservation.billing.total_used_capacity_billed{${local.res}}", q2 = "avg:everpure.reservation.billing.total_used_capacity_reported{${local.res}}", formula = "q - q2", unit = local.byte_unit, precision = 2 },
    { title = "Overage", q = "avg:everpure.reservation.billing.total_used_capacity_overage{${local.res}}", unit = local.byte_unit, precision = 2 },
    { title = "Perf Billed", q = "avg:everpure.reservation.billing.total_performance_reported{${local.res}}", unit = null, custom_unit = "MB/s", precision = 1 },
    { title = "Billing DRR", q = "avg:everpure.reservation.billing.drr_weighted_average{${local.res}}", unit = null, custom_unit = ":1", precision = 2 },
  ]

  # ------------------------------------------------------------ trend charts
  # each series = { alias, q }. One chart per entry.
  perf_trends = [
    {
      title = "Bandwidth", unit = local.bps_unit, series = [
        { alias = "read", q = "avg:purefa.array.performance_bandwidth_bytes{${local.pool},dimension:read_bytes_per_sec} by {storage_pool}" },
        { alias = "write", q = "avg:purefa.array.performance_bandwidth_bytes{${local.pool},dimension:write_bytes_per_sec} by {storage_pool}" },
      ]
    },
    {
      title = "IOPS", unit = local.iops_unit, series = [
        { alias = "read", q = "avg:purefa.array.performance_throughput_iops{${local.pool},dimension:reads_per_sec} by {storage_pool}" },
        { alias = "write", q = "avg:purefa.array.performance_throughput_iops{${local.pool},dimension:writes_per_sec} by {storage_pool}" },
      ]
    },
    {
      title = "Latency", unit = local.usec_unit, series = [
        { alias = "read", q = "avg:purefa.array.performance_latency_usec{${local.pool},dimension:usec_per_read_op} by {storage_pool}" },
        { alias = "write", q = "avg:purefa.array.performance_latency_usec{${local.pool},dimension:usec_per_write_op} by {storage_pool}" },
      ]
    },
  ]

  arm_trends = [
    {
      title = "IOPS: current vs provisioned vs max (ARM)", unit = local.iops_unit, palette = "classic", series = [
        { alias = "current", q = "avg:everpure.pool.iops.current{${local.arm}} by {storage_pool}" },
        { alias = "provisioned", q = "avg:everpure.pool.iops.provisioned{${local.arm}} by {storage_pool}" },
        { alias = "max", q = "avg:everpure.pool.iops.max{${local.arm}} by {storage_pool}" },
      ]
    },
    {
      title = "Bandwidth: current vs provisioned vs max (ARM)", unit = local.bps_unit, palette = "classic", series = [
        { alias = "current", q = "avg:everpure.pool.bandwidth_bytes.current{${local.arm}} by {storage_pool}" },
        { alias = "provisioned", q = "avg:everpure.pool.bandwidth_bytes.provisioned{${local.arm}} by {storage_pool}" },
        { alias = "max", q = "avg:everpure.pool.bandwidth_bytes.max{${local.arm}} by {storage_pool}" },
      ]
    },
  ]

  billing_trends = [
    {
      title = "Billed vs Used Capacity", unit = local.byte_unit, series = [
        { alias = "billed", q = "avg:everpure.reservation.billing.total_used_capacity_billed{${local.res}} by {reservation}" },
        { alias = "used", q = "avg:everpure.reservation.billing.total_used_capacity_reported{${local.res}} by {reservation}" },
        { alias = "low usage rounding", q = "avg:everpure.reservation.billing.extra_used_capacity_low_usage_rounding{${local.res}} by {reservation}" },
        { alias = "included in plan", q = "avg:everpure.reservation.billing.total_used_capacity_included_plan{${local.res}} by {reservation}" },
      ]
    },
    {
      title = "Performance Billing (MB/s)", unit = null, series = [
        { alias = "reported", q = "avg:everpure.reservation.billing.total_performance_reported{${local.res}} by {reservation}" },
        { alias = "included in plan", q = "avg:everpure.reservation.billing.total_performance_included_plan{${local.res}} by {reservation}" },
        { alias = "overage", q = "avg:everpure.reservation.billing.total_performance_overage{${local.res}} by {reservation}" },
      ]
    },
  ]

  capacity_series = [
    for s in ["unique", "shared", "snapshots", "replication"] :
    { alias = s, q = "sum:purefa.array.space_bytes{${local.pool},space:${s}} by {storage_pool}" }
  ]

  # ------------------------------------------------------------ builders
  stat_widget = { for k, v in {
    overview = local.overview_stats
    arm      = local.arm_stats
    billing  = local.billing_stats
    tv       = local.tv_stats
    } : k => [
    for i, s in v : {
      # custom_unit is merged in only when set: the API rejects "custom_unit": null
      definition = merge(try(s.custom_unit, null) == null ? {} : { custom_unit = s.custom_unit }, {
        type      = "query_value"
        title     = s.title
        autoscale = try(s.autoscale, true)
        precision = s.precision
        requests = [{
          response_format = "scalar"
          queries = concat(
            [{ data_source = "metrics", name = "q", query = s.q, aggregator = "last" }],
            try(s.q2, null) == null ? [] : [{ data_source = "metrics", name = "q2", query = s.q2, aggregator = "last" }]
          )
          formulas = [merge(
            { formula = try(s.formula, "q") },
            s.unit == null ? {} : { number_format = { unit = s.unit } }
          )]
          conditional_formats = [{
            comparator      = ">="
            value           = -1e15
            palette         = "custom_text"
            custom_fg_color = try(s.hero, false) ? local.pure_orange : local.ash_gray
          }]
        }]
      })
      layout = { x = (i % 6) * 2, y = 0, width = 2, height = 2 }
    }
  ] }

  trend_widget = { for k, v in {
    perf    = local.perf_trends
    arm     = local.arm_trends
    billing = local.billing_trends
    } : k => [
    for i, t in v : {
      definition = {
        type          = "timeseries"
        title         = t.title
        show_legend   = true
        legend_layout = "horizontal"
        # one request per series so each gets its own palette and line style; no
        # palette_index, so every pool (or reservation) takes a different shade of it
        requests = [for j, s in t.series : {
          response_format = "timeseries"
          display_type    = "line"
          # a chart-level palette keeps each pool one colour across its series (line style tells current from max).
          # "classic" is Datadog's consistent palette: colour comes from the tag value, so pools get distinct hues.
          style   = { palette = try(t.palette, local.series_style[j].palette), line_type = local.series_style[j].line, line_width = "normal" }
          queries = [{ data_source = "metrics", name = "q${j}", query = s.q }]
          formulas = [merge(
            { formula = "q${j}", alias = s.alias },
            t.unit == null ? {} : { number_format = { unit = t.unit } }
          )]
        }]
      }
      layout = { x = (i % 2) * 6, y = 2 + floor(i / 2) * 3, width = length(v) == 1 ? 12 : 6, height = 3 }
    }
  ] }

  # ------------------------------------------------------------ volumes (OpenMetrics only)
  # ARM has no per-volume data. purefa.volume.* is per volume (name:<vg>/<vol>),
  # purefa.volume_group.* is per volume group, i.e. per connected VM in this setup.
  # !name:sp-* drops the pool's internal volume.
  vol = "${local.pool},$volume,!name:sp-*"

  vol_table_cols = [
    { alias = "Read IOPS", q = "avg:purefa.volume.performance_throughput_iops{${local.vol},dimension:reads_per_sec} by {name}", unit = local.iops_unit },
    { alias = "Write IOPS", q = "avg:purefa.volume.performance_throughput_iops{${local.vol},dimension:writes_per_sec} by {name}", unit = local.iops_unit },
    { alias = "Read Latency", q = "avg:purefa.volume.performance_latency_usec{${local.vol},dimension:usec_per_read_op} by {name}", unit = local.usec_unit },
    { alias = "Write Latency", q = "avg:purefa.volume.performance_latency_usec{${local.vol},dimension:usec_per_write_op} by {name}", unit = local.usec_unit },
    { alias = "Read BW", q = "avg:purefa.volume.performance_bandwidth_bytes{${local.vol},dimension:read_bytes_per_sec} by {name}", unit = local.bps_unit },
    { alias = "Write BW", q = "avg:purefa.volume.performance_bandwidth_bytes{${local.vol},dimension:write_bytes_per_sec} by {name}", unit = local.bps_unit },
    { alias = "Written", q = "avg:purefa.volume.space_bytes{${local.vol},space:virtual} by {name}", unit = local.byte_unit },
    { alias = "Physical", q = "avg:purefa.volume.space_bytes{${local.vol},space:unique} by {name}", unit = local.byte_unit },
  ]

  # one chart per entry; formula combines the queries, series split by {name}
  vol_charts = [
    {
      title = "IOPS by Volume", unit = local.iops_unit, formula = "q0 + q1", x = 0, y = 4, queries = [
        "sum:purefa.volume.performance_throughput_iops{${local.vol},dimension:reads_per_sec} by {name}",
        "sum:purefa.volume.performance_throughput_iops{${local.vol},dimension:writes_per_sec} by {name}",
      ]
    },
    {
      title = "Bandwidth by Volume", unit = local.bps_unit, formula = "q0 + q1", x = 6, y = 4, queries = [
        "sum:purefa.volume.performance_bandwidth_bytes{${local.vol},dimension:read_bytes_per_sec} by {name}",
        "sum:purefa.volume.performance_bandwidth_bytes{${local.vol},dimension:write_bytes_per_sec} by {name}",
      ]
    },
    {
      title = "Read Latency by Volume", unit = local.usec_unit, formula = "q0", x = 0, y = 7, queries = [
        "avg:purefa.volume.performance_latency_usec{${local.vol},dimension:usec_per_read_op} by {name}",
      ]
    },
    {
      title = "Write Latency by Volume", unit = local.usec_unit, formula = "q0", x = 6, y = 7, queries = [
        "avg:purefa.volume.performance_latency_usec{${local.vol},dimension:usec_per_write_op} by {name}",
      ]
    },
  ]

  volume_widgets = concat(
    [{
      definition = {
        type           = "query_table"
        title          = "Volume Performance"
        has_search_bar = "auto"
        requests = [{
          response_format = "scalar"
          queries         = [for j, c in local.vol_table_cols : { data_source = "metrics", name = "q${j}", query = c.q, aggregator = "avg" }]
          formulas = [for j, c in local.vol_table_cols : merge(
            { formula = "q${j}", alias = c.alias, number_format = { unit = c.unit } },
            j == 0 ? { limit = { count = 50, order = "desc" } } : {}
          )]
        }]
      }
      layout = { x = 0, y = 0, width = 12, height = 4 }
    }],
    [for c in local.vol_charts : {
      definition = {
        type          = "timeseries"
        title         = c.title
        show_legend   = true
        legend_layout = "horizontal"
        requests = [{
          response_format = "timeseries"
          display_type    = "line"
          style           = { palette = "orange", line_type = "solid", line_width = "normal" }
          queries         = [for j, q in c.queries : { data_source = "metrics", name = "q${j}", query = q }]
          formulas        = [{ formula = c.formula, number_format = { unit = c.unit } }]
        }]
      }
      layout = { x = c.x, y = c.y, width = 6, height = 3 }
    }],
    [{
      # per volume group (one per VM here) against its QoS IOPS limit
      definition = {
        type          = "timeseries"
        title         = "Volume Group IOPS vs QoS Limit"
        show_legend   = true
        legend_layout = "horizontal"
        requests = [{
          response_format = "timeseries"
          display_type    = "line"
          queries = [
            { data_source = "metrics", name = "q0", query = "sum:purefa.volume_group.performance_throughput_iops{${local.pool},dimension:reads_per_sec} by {name}" },
            { data_source = "metrics", name = "q1", query = "sum:purefa.volume_group.performance_throughput_iops{${local.pool},dimension:writes_per_sec} by {name}" },
            { data_source = "metrics", name = "q2", query = "avg:purefa.volume_group.qos_iops_limit{${local.pool}} by {name}" },
          ]
          formulas = [
            { formula = "q0 + q1", alias = "iops", style = { palette = "orange" }, number_format = { unit = local.iops_unit } },
            { formula = "q2", alias = "qos limit", style = { palette = "gray" }, number_format = { unit = local.iops_unit } },
          ]
        }]
      }
      layout = { x = 0, y = 10, width = 12, height = 3 }
    }]
  )

  # ------------------------------------------------------------ logo and help
  # Official files from the Everpure brand assets, embedded so Datadog doesn't need to reach
  # a private repo. Set var.logo_url to a public URL instead if you'd rather host it.
  logo_light = coalesce(var.logo_url, "data:image/png;base64,${filebase64("${path.module}/assets/everpure-logo-ashgray.png")}")
  logo_dark  = coalesce(var.logo_url_dark, var.logo_url, "data:image/png;base64,${filebase64("${path.module}/assets/everpure-logo-cloudwhite.png")}")

  help_text = <<-EOT
    **Everpure Cloud Azure Native** storage pool observability. Purity OpenMetrics from the platform console (`purefa.*`) and Azure ARM health, usage and billing (`everpure.*`).

    - **Filters:** `subscription`, `storage_pool`, `reservation` and `volume` at the top. `subscription` applies to the Fleet and ARM sections only.
    - **Pools without a platform console** only show up in Fleet and the ARM and Billing sections. Overview, Performance, Volumes and Capacity need OpenMetrics.
    - **Billing** comes from `getBillingStatus` on the reservation and updates hourly. Billed includes the low-usage minimum, so a nearly empty pool still bills the minimum capacity. Headroom is billed minus used, how much you can write before the bill grows.
    - `getBillingReport` currently returns HTTP 500 and shows as a WARNING service check `everpure.reservation.billing_report_api`.
  EOT

  # ------------------------------------------------------------ fleet (ARM only)
  # One row per pool across every subscription the everpure_arm check can see. Works for
  # pools without a platform console, which only have the ARM side.
  fleet_cols = [
    { alias = "IOPS", q = "avg:everpure.pool.iops.current{${local.arm}} by {subscription_name,storage_pool}", unit = local.iops_unit },
    { alias = "IOPS % Prov", round = 2, q = "avg:everpure.pool.iops.pct_of_provisioned{${local.arm}} by {subscription_name,storage_pool}", unit = local.pct_unit },
    { alias = "Bandwidth", q = "avg:everpure.pool.bandwidth_bytes.current{${local.arm}} by {subscription_name,storage_pool}", unit = local.bps_unit },
    { alias = "BW % Prov", round = 2, q = "avg:everpure.pool.bandwidth_bytes.pct_of_provisioned{${local.arm}} by {subscription_name,storage_pool}", unit = local.pct_unit },
    { alias = "Used", q = "avg:everpure.pool.space_bytes.total_used{${local.arm}} by {subscription_name,storage_pool}", unit = local.byte_unit },
    { alias = "DRR", round = 1, q = "avg:everpure.pool.data_reduction_ratio{${local.arm}} by {subscription_name,storage_pool}", unit = null },
    { alias = "Alerts", round = 0, q = "max:everpure.pool.alerts{${local.arm}} by {subscription_name,storage_pool}", unit = null },
  ]

  fleet_widgets = [
    {
      definition = {
        type           = "query_table"
        title          = "All Pools (ARM)"
        has_search_bar = "auto"
        requests = [{
          response_format = "scalar"
          queries         = [for j, c in local.fleet_cols : { data_source = "metrics", name = "q${j}", query = c.q, aggregator = "last" }]
          formulas = [for j, c in local.fleet_cols : merge(
            # round() keeps tiny values on idle pools from rendering as 6.7e-4 %
            { formula = try(c.round, null) == null ? "q${j}" : "round(q${j}, ${c.round})", alias = c.alias },
            c.unit == null ? {} : { number_format = { unit = c.unit } },
            j == 0 ? { limit = { count = 200, order = "desc" } } : {}
          )]
        }]
      }
      layout = { x = 0, y = 0, width = 12, height = 4 }
    },
    {
      definition = {
        type  = "toplist"
        title = "Busiest Pools by IOPS"
        requests = [{
          response_format = "scalar"
          queries         = [{ data_source = "metrics", name = "q", aggregator = "avg", query = "avg:everpure.pool.iops.current{${local.arm}} by {subscription_name,storage_pool}" }]
          formulas        = [{ formula = "q", limit = { count = 10, order = "desc" } }]
        }]
      }
      layout = { x = 0, y = 4, width = 6, height = 3 }
    },
    {
      definition = {
        type  = "toplist"
        title = "Largest Pools by Used Capacity"
        requests = [{
          response_format = "scalar"
          queries         = [{ data_source = "metrics", name = "q", aggregator = "last", query = "avg:everpure.pool.space_bytes.total_used{${local.arm}} by {subscription_name,storage_pool}" }]
          formulas        = [{ formula = "q", number_format = { unit = local.byte_unit }, limit = { count = 10, order = "desc" } }]
        }]
      }
      layout = { x = 6, y = 4, width = 6, height = 3 }
    },
  ]

  # ------------------------------------------------------------ page layout
  # High density mode (on by default on wide screens and in TV mode) shows the page as two
  # 12-column grids side by side. y runs continuously down the page (the single-column order on
  # narrow screens); is_column_break on the first right group starts the second grid,
  # so OpenMetrics sections sit on the left and ARM, fleet and billing on the right.
  left_groups = [
    {
      # official Everpure logo, top-left. Ash Gray on the light theme, Cloud White on dark.
      definition = {
        type        = "group"
        title       = "Everpure"
        layout_type = "ordered"
        widgets = [{
          definition = {
            type             = "image"
            url              = local.logo_light
            url_dark_theme   = local.logo_dark
            sizing           = "contain"
            has_background   = false
            has_border       = false
            horizontal_align = "left"
            vertical_align   = "center"
          }
          layout = { x = 0, y = 0, width = 4, height = 1 }
        }]
      }
    },
    {
      definition = {
        type        = "group"
        title       = "Overview (Purity OpenMetrics)"
        layout_type = "ordered"
        widgets     = local.stat_widget.overview
      }
    },
    {
      definition = {
        type        = "group"
        title       = "Performance"
        layout_type = "ordered"
        widgets = concat(
          [for w in local.trend_widget.perf : merge(w, { layout = merge(w.layout, { y = w.layout.y - 2 }) })],
          [{
            definition = {
              type  = "toplist"
              title = "Top Volumes by IOPS"
              requests = [{
                response_format = "scalar"
                queries = [{
                  data_source = "metrics", name = "q", aggregator = "avg"
                  query       = "sum:purefa.volume.performance_throughput_iops{${local.pool}} by {name}"
                }]
                formulas = [{ formula = "q", limit = { count = 10, order = "desc" } }]
              }]
            }
            layout = { x = 6, y = 3, width = 6, height = 3 }
            }, {
            definition = {
              type  = "toplist"
              title = "Top Volumes by Bandwidth"
              requests = [{
                response_format = "scalar"
                queries = [{
                  data_source = "metrics", name = "q", aggregator = "avg"
                  query       = "sum:purefa.volume.performance_bandwidth_bytes{${local.pool}} by {name}"
                }]
                formulas = [{ formula = "q", number_format = { unit = local.bps_unit }, limit = { count = 10, order = "desc" } }]
              }]
            }
            layout = { x = 0, y = 6, width = 12, height = 3 }
          }]
        )
      }
    },
    {
      definition = {
        type        = "group"
        title       = "Volumes"
        layout_type = "ordered"
        widgets     = local.volume_widgets
      }
    },
    {
      definition = {
        type        = "group"
        title       = "Capacity"
        layout_type = "ordered"
        widgets = [{
          definition = {
            type        = "timeseries"
            title       = "Capacity by Type"
            show_legend = true
            requests = [{
              response_format = "timeseries"
              display_type    = "area"
              style           = { palette = "orange" }
              queries         = [for j, s in local.capacity_series : { data_source = "metrics", name = "q${j}", query = s.q }]
              formulas        = [for j, s in local.capacity_series : { formula = "q${j}", alias = s.alias, number_format = { unit = local.byte_unit } }]
            }]
          }
          layout = { x = 0, y = 0, width = 12, height = 3 }
        }]
      }
    },
  ]

  right_groups = [
    {
      definition = {
        type        = "group"
        title       = "Fleet: All Pools (ARM)"
        layout_type = "ordered"
        widgets     = local.fleet_widgets
      }
    },
    {
      definition = {
        type        = "group"
        title       = "Azure ARM: Usage vs Provisioned"
        layout_type = "ordered"
        widgets = concat(
          local.stat_widget.arm,
          local.trend_widget.arm,
          [{
            definition = {
              type     = "check_status"
              title    = "ARM Health API"
              check    = "everpure.pool.health_api"
              grouping = "cluster"
              group_by = []
              tags     = ["$storage_pool", "$subscription", local.platform]
            }
            layout = { x = 0, y = 5, width = 3, height = 2 }
          }]
        )
      }
    },
    {
      definition = {
        type        = "group"
        title       = "Billing (Reservation)"
        layout_type = "ordered"
        widgets = concat(
          local.stat_widget.billing,
          local.trend_widget.billing,
        )
      }
    },
    {
      # every tip in one place, at the bottom
      definition = {
        type        = "group"
        title       = "About This Dashboard"
        layout_type = "ordered"
        widgets = [{
          definition = {
            type             = "note"
            content          = local.help_text
            background_color = "white"
            font_size        = "14"
            text_align       = "left"
            vertical_align   = "top"
            show_tick        = false
            has_padding      = true
          }
          layout = { x = 0, y = 0, width = 12, height = 2 }
        }]
      }
    },
  ]

  # group height = its tallest child + 1 row for the title; y stacks within each column
  group_heights = { for side, gs in { left = local.left_groups, right = local.right_groups } : side => [
    for g in gs : max([for w in g.definition.widgets : w.layout.y + w.layout.height]...) + 1
  ] }

  page_widgets = concat(
    [for i, g in local.left_groups : merge(g, { layout = { x = 0, y = i == 0 ? 0 : sum(slice(local.group_heights.left, 0, i)), width = 12, height = local.group_heights.left[i] } })],
    [for i, g in local.right_groups : merge(g, { layout = merge(
      { x = 0, y = sum(local.group_heights.left) + (i == 0 ? 0 : sum(slice(local.group_heights.right, 0, i))), width = 12, height = local.group_heights.right[i] },
      i == 0 ? { is_column_break = true } : {}
    ) })],
  )

  dashboard = {
    title       = var.dashboard_title
    description = "Everpure Cloud Azure Native storage pools. Purity OpenMetrics from the platform console (purefa.*) plus Azure ARM health, usage and billing (everpure.*). Managed by Terraform."
    layout_type = "ordered"
    reflow_type = "fixed"
    template_variables = [
      { name = "storage_pool", prefix = "storage_pool", available_values = [], default = "*" },
      { name = "reservation", prefix = "reservation", available_values = [], default = "*" },
      { name = "subscription", prefix = "subscription_name", available_values = [], default = "*" },
      # purefa volume metrics tag the volume as name:<volume group>/<volume>
      { name = "volume", prefix = "name", available_values = [], default = "*" },
    ]
    widgets = local.page_widgets
  }
}

resource "datadog_dashboard_json" "everpure_azure_native" {
  dashboard = jsonencode(local.dashboard)
}

output "dashboard_url" {
  value = datadog_dashboard_json.everpure_azure_native.url
}

# lets you import the dashboard by hand (Dashboards -> New -> Import JSON) without Terraform
resource "local_file" "dashboard_json" {
  filename = "${path.module}/dashboard.json"
  content  = jsonencode(local.dashboard)
}
