# TV / wall-screen version of the dashboard.
#
# TV mode never scrolls: it scales the whole page to fit the screen height. The main
# dashboard is about 30 rows tall, so on a 16:9 screen it shrinks to a strip in the middle.
# This one is two 12-column grids of 13 rows (high density puts them side by side), which is
# close to 16:9 and fills the width. Widgets are reused from dashboard.tf by title, so the
# queries stay in one place.

locals {
  # every widget on the main dashboard, keyed by title (all titles are unique)
  main_widgets = {
    for w in flatten([for g in concat(local.left_groups, local.right_groups) : g.definition.widgets]) :
    w.definition.title => w.definition if can(w.definition.title)
  }
  logo_widget = local.left_groups[0].definition.widgets[0].definition
  tv_stat     = { for w in local.stat_widget.tv : w.definition.title => w.definition }

  # the main dashboard's hero cards are orange; on the TV each column keeps just one
  tv_plain = { for k, v in local.main_widgets : k => jsondecode(replace(jsonencode(v), local.pure_orange, local.ash_gray)) }

  # [definition, x, y, width, height]; y is per column and gets offset below
  tv_left = [
    [local.logo_widget, 0, 0, 4, 2],
    [local.main_widgets["Data Reduction"], 4, 0, 2, 2],
    [local.main_widgets["Read IOPS"], 6, 0, 2, 2],
    [local.main_widgets["Write IOPS"], 8, 0, 2, 2],
    [local.main_widgets["Write Latency"], 10, 0, 2, 2],
    [local.main_widgets["Bandwidth"], 0, 2, 6, 4],
    [local.main_widgets["IOPS"], 6, 2, 6, 4],
    [local.main_widgets["Latency"], 0, 6, 4, 4],
    [local.main_widgets["Top Volumes by IOPS"], 4, 6, 4, 4],
    [local.main_widgets["Top Volumes by Bandwidth"], 8, 6, 4, 4],
    [local.main_widgets["IOPS by Volume"], 0, 10, 4, 3],
    [local.main_widgets["Bandwidth by Volume"], 4, 10, 4, 3],
    [local.main_widgets["Capacity by Type"], 8, 10, 4, 3],
  ]

  tv_right = [
    # used next to provisioned, as numbers; percents per pool are in the fleet table
    [local.tv_stat["IOPS"], 0, 0, 2, 2],
    [local.tv_stat["IOPS Prov"], 2, 0, 2, 2],
    [local.tv_stat["Bandwidth"], 4, 0, 2, 2],
    [local.tv_stat["BW Prov"], 6, 0, 2, 2],
    # total physical capacity used across the pools in the filter (after data reduction)
    [merge(local.tv_plain["Used"], { title = "Capacity Used", precision = 1 }), 8, 0, 2, 2],
    # count of pools whose ARM health call succeeded
    [merge(local.main_widgets["ARM Health API"], { title = "Pools Healthy" }), 10, 0, 2, 2],
    [local.main_widgets["All Pools (ARM)"], 0, 2, 12, 4],
    [local.main_widgets["IOPS: current vs provisioned vs max (ARM)"], 0, 6, 6, 4],
    [local.main_widgets["Bandwidth: current vs provisioned vs max (ARM)"], 6, 6, 6, 4],
    [local.main_widgets["Billed vs Used Capacity"], 0, 10, 12, 3],
  ]

  tv_rows = 13

  tv_dashboard = {
    title       = "${var.dashboard_title} (TV)"
    description = "Wall-screen version of ${var.dashboard_title}, sized for TV mode on a 16:9 screen. Managed by Terraform."
    layout_type = "ordered"
    reflow_type = "fixed"
    # same filters as the main dashboard; the volume widgets reference $volume
    template_variables = local.dashboard.template_variables
    widgets = concat(
      [for w in local.tv_left : { definition = w[0], layout = { x = w[1], y = w[2], width = w[3], height = w[4] } }],
      # the first right-hand widget starts the second high density column
      [for i, w in local.tv_right : {
        definition = w[0]
        layout = merge(
          { x = w[1], y = local.tv_rows + w[2], width = w[3], height = w[4] },
          i == 0 ? { is_column_break = true } : {}
        )
      }],
    )
  }
}

resource "datadog_dashboard_json" "everpure_azure_native_tv" {
  dashboard = jsonencode(local.tv_dashboard)
}

output "tv_dashboard_url" {
  value = datadog_dashboard_json.everpure_azure_native_tv.url
}

resource "local_file" "tv_dashboard_json" {
  filename = "${path.module}/dashboard-tv.json"
  content  = jsonencode(local.tv_dashboard)
}
