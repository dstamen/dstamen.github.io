variable "datadog_api_key" {
  description = "Datadog API key (Organization Settings -> API Keys)"
  type        = string
  sensitive   = true
}

variable "datadog_app_key" {
  description = "Datadog application key with dashboards_write"
  type        = string
  sensitive   = true
}

variable "datadog_api_url" {
  description = "Datadog API URL for your site, e.g. https://api.datadoghq.com/ or https://api.us3.datadoghq.com/"
  type        = string
  default     = "https://api.datadoghq.com/"
}

variable "dashboard_title" {
  type    = string
  default = "Everpure Cloud Azure Native"
}

variable "logo_url" {
  description = "Optional public URL of the official Everpure logo (Ash Gray). Null embeds assets/everpure-logo-ashgray.png."
  type        = string
  default     = null
}

variable "logo_url_dark" {
  description = "Optional public URL of the Cloud White logo for Datadog's dark theme. Null embeds assets/everpure-logo-cloudwhite.png."
  type        = string
  default     = null
}
