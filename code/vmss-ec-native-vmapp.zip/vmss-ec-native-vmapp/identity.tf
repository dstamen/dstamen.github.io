# The scale set's own identity. Every instance uses it (via IMDS) to create and
# delete its volume group and to push the mount extension onto itself.
resource "azurerm_user_assigned_identity" "agent" {
  name                = "${var.vmss_name}-agent"
  resource_group_name = azurerm_resource_group.lab.name
  location            = var.location
  tags                = var.tags
}
