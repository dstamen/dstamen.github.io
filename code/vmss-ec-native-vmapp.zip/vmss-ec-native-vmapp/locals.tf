locals {
  vg_api_version      = "2026-01-01-preview"
  volume_api_version  = "2026-05-01-preview"
  mount_api_version   = "2026-05-01-preview"
  compute_api_version = "2024-07-01"

  pool_rg_ids = distinct([
    for pool in var.storage_pools_by_zone : "/subscriptions/${var.subscription_id}/resourceGroups/${pool.resource_group}"
  ])

  # Everything the agent needs, handed to each instance through userData (IMDS).
  agent_config = {
    vmss         = var.vmss_name
    location     = var.location
    volSizeBytes = var.vol_size_bytes
    clientId     = azurerm_user_assigned_identity.agent.client_id
    pools        = { for zone, pool in data.azapi_resource.storage_pool : zone => pool.id }
    vgApi        = local.vg_api_version
    volApi       = local.volume_api_version
    mountApi     = local.mount_api_version
    computeApi   = local.compute_api_version
  }
}
