# VMSS + Everpure Cloud Azure Native, agent as a VM Application

Proof of concept, not an officially supported pattern.

Every VMSS instance gets its own Everpure Cloud Azure Native volume group and
volume, formatted and mounted at /mnt/ecvol on boot, and deleted on scale-in.
No Azure Function: the agent ships as a VM Application from an Azure Compute
Gallery and uses the scale set's user-assigned managed identity.

1. Copy terraform.auto.tfvars.example to terraform.auto.tfvars and fill it in.
2. terraform init && terraform apply
3. az vmss scale -n <vmss_name> -g <resource_group> --new-capacity 2

To ship an agent change, edit app/ and bump app_version.
