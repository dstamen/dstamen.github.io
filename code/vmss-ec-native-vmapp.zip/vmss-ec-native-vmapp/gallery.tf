# The agent ships as a VM Application: a zip of app/ uploaded to blob storage,
# published as a versioned gallery application, and installed by the VMSS.

resource "random_string" "sa_suffix" {
  length  = 6
  special = false
  upper   = false
}

resource "azurerm_storage_account" "pkg" {
  name                            = "stecagent${random_string.sa_suffix.result}"
  resource_group_name             = azurerm_resource_group.lab.name
  location                        = var.location
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  allow_nested_items_to_be_public = false
  tags                            = var.tags
}

resource "azurerm_storage_container" "pkg" {
  name                  = "packages"
  storage_account_id    = azurerm_storage_account.pkg.id
  container_access_type = "private"
}

data "archive_file" "agent" {
  type        = "zip"
  source_dir  = "${path.module}/app"
  output_path = "${path.module}/.build/ec-agent-${var.app_version}.zip"
}

resource "azurerm_storage_blob" "agent" {
  name                 = "ec-agent-${var.app_version}.zip"
  storage_container_id = azurerm_storage_container.pkg.id
  type                 = "Block"
  source               = data.archive_file.agent.output_path
  content_md5          = data.archive_file.agent.output_md5
}

# Short-lived read SAS so the gallery can copy the package in. The gallery keeps
# its own copy, so the SAS only has to be valid while the version is created.
data "azurerm_storage_account_blob_container_sas" "pkg" {
  connection_string = azurerm_storage_account.pkg.primary_connection_string
  container_name    = azurerm_storage_container.pkg.name
  https_only        = true
  start             = timeadd(timestamp(), "-1h")
  expiry            = timeadd(timestamp(), "48h")

  permissions {
    read   = true
    add    = false
    create = false
    write  = false
    delete = false
    list   = false
  }
}

resource "azurerm_shared_image_gallery" "gallery" {
  name                = var.gallery_name
  resource_group_name = azurerm_resource_group.lab.name
  location            = var.location
  description         = "Everpure Cloud Azure Native VMSS agent"
  tags                = var.tags
}

resource "azurerm_gallery_application" "agent" {
  name              = "ec-agent"
  gallery_id        = azurerm_shared_image_gallery.gallery.id
  location          = var.location
  supported_os_type = "Linux"
  description       = "Per-instance Everpure Cloud Azure Native volume agent"
  tags              = var.tags
}

resource "azurerm_gallery_application_version" "agent" {
  name                   = var.app_version
  gallery_application_id = azurerm_gallery_application.agent.id
  location               = var.location
  package_file           = "ec-agent.zip"
  tags                   = var.tags

  manage_action {
    install = "python3 -m zipfile -e ec-agent.zip /opt/ec-agent && bash /opt/ec-agent/install.sh"
    update  = "python3 -m zipfile -e ec-agent.zip /opt/ec-agent && bash /opt/ec-agent/install.sh"
    remove  = "bash /opt/ec-agent/remove.sh"
  }

  source {
    media_link = "${azurerm_storage_blob.agent.url}${data.azurerm_storage_account_blob_container_sas.pkg.sas}"
  }

  target_region {
    name                   = var.location
    regional_replica_count = 1
    storage_account_type   = "Standard_LRS"
  }

  # The SAS in media_link changes on every plan. A new package ships as a new
  # app_version, which is a new resource.
  lifecycle {
    ignore_changes        = [source]
    create_before_destroy = true
  }
}
