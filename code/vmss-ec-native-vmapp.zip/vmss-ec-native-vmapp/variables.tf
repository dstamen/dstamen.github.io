variable "subscription_id" {
  type = string
}

variable "location" {
  type = string
}

variable "resource_group" {
  type        = string
  description = "Resource group for the VMSS, identity and gallery. Managed here, so destroy removes it."
}

variable "vnet_resource_group" {
  type = string
}

variable "vnet_name" {
  type = string
}

variable "subnet_name" {
  type        = string
  description = "VM subnet. Needs outbound access (apt) and a route to the pools' iSCSI endpoints."
}

variable "storage_pools_by_zone" {
  type = map(object({
    name           = string
    resource_group = string
  }))
  description = "Availability zone -> existing storage pool in that zone. Instances in a zone with no entry get no volume."
}

variable "zones" {
  type    = list(string)
  default = ["1", "2"]
}

variable "vmss_name" {
  type = string
}

variable "vm_size" {
  type    = string
  default = "Standard_B2s_v2"
}

variable "instance_count" {
  type        = number
  default     = 0
  description = "Initial count only; scaling is done outside Terraform."
}

variable "admin_username" {
  type    = string
  default = "azureuser"
}

variable "admin_ssh_public_key" {
  type = string
}

variable "vol_size_bytes" {
  type    = number
  default = 32212254720 # 30 GiB
}

variable "gallery_name" {
  type        = string
  description = "Azure Compute Gallery name (letters, numbers, underscores, periods)."
}

variable "app_version" {
  type        = string
  description = "VM Application version (x.y.z). Bump it to ship a change to the agent."
  default     = "1.0.0"
}

variable "tags" {
  type    = map(string)
  default = {}
}
