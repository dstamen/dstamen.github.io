data "azurerm_subnet" "vm" {
  name                 = var.subnet_name
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group
}

# One existing storage pool per zone.
data "azapi_resource" "storage_pool" {
  for_each  = var.storage_pools_by_zone
  type      = "PureStorage.Block/storagePools@2024-11-01-preview"
  name      = each.value.name
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${each.value.resource_group}"
}
