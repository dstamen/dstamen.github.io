resource "azurerm_resource_group" "lab" {
  name     = var.resource_group
  location = var.location
  tags     = var.tags
}
