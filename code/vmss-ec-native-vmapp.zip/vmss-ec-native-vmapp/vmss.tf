resource "azurerm_linux_virtual_machine_scale_set" "lab" {
  name                = var.vmss_name
  resource_group_name = azurerm_resource_group.lab.name
  location            = var.location
  sku                 = var.vm_size
  instances           = var.instance_count
  upgrade_mode        = "Manual"
  zones               = var.zones
  tags                = var.tags

  admin_username = var.admin_username
  admin_ssh_key {
    username   = var.admin_username
    public_key = var.admin_ssh_public_key
  }
  disable_password_authentication = true

  identity {
    type         = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.agent.id]
  }

  # The agent's config. No secrets: auth is the managed identity.
  user_data = base64encode(jsonencode(local.agent_config))

  # Required: without it there's no Terminate scheduled event to clean up on.
  termination_notification {
    enabled = true
    timeout = "PT5M"
  }

  boot_diagnostics {
    storage_account_uri = null
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }

  os_disk {
    storage_account_type = "StandardSSD_LRS"
    caching              = "ReadWrite"
  }

  network_interface {
    name    = "${var.vmss_name}-nic"
    primary = true

    ip_configuration {
      name      = "internal"
      primary   = true
      subnet_id = data.azurerm_subnet.vm.id
    }
  }

  lifecycle {
    # gallery_application is managed by azapi_update_resource.vmss_apps below.
    ignore_changes = [instances, gallery_application]
  }
}

# azurerm treats gallery_application.version_id as force-new, so a new agent
# version would recreate the whole scale set. Azure itself updates the
# application profile in place, so set it with a PATCH instead. New instances
# (and upgraded ones) get the new version; running instances keep theirs.
resource "azapi_update_resource" "vmss_apps" {
  type        = "Microsoft.Compute/virtualMachineScaleSets@${local.compute_api_version}"
  resource_id = azurerm_linux_virtual_machine_scale_set.lab.id

  body = {
    properties = {
      virtualMachineProfile = {
        applicationProfile = {
          galleryApplications = [{
            packageReferenceId = azurerm_gallery_application_version.agent.id
            order              = 1
          }]
        }
      }
    }
  }
}

output "vmss_id" {
  value = azurerm_linux_virtual_machine_scale_set.lab.id
}

output "agent_identity_client_id" {
  value = azurerm_user_assigned_identity.agent.client_id
}
