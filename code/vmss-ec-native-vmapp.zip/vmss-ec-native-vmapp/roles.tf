# Least-privilege custom roles for the instances' managed identity, scoped to
# each pool and to the one VMSS.

resource "azurerm_role_definition" "agent_storage" {
  name        = "EC native volume agent (${var.vmss_name})"
  scope       = "/subscriptions/${var.subscription_id}"
  description = "Create, read and delete Everpure Cloud Azure Native volume groups and volumes in a storage pool."

  permissions {
    actions = [
      "PureStorage.Block/storagePools/read",
      "PureStorage.Block/storagePools/volumeGroups/read",
      "PureStorage.Block/storagePools/volumeGroups/write",
      "PureStorage.Block/storagePools/volumeGroups/delete",
      "PureStorage.Block/storagePools/volumeGroups/listConnectionParameters/action",
      "PureStorage.Block/storagePools/volumeGroups/volumes/read",
      "PureStorage.Block/storagePools/volumeGroups/volumes/write",
      "PureStorage.Block/storagePools/volumeGroups/volumes/delete",
    ]
  }

  assignable_scopes = local.pool_rg_ids
}

resource "azurerm_role_definition" "agent_vmss" {
  name        = "EC native VMSS extension agent (${var.vmss_name})"
  scope       = "/subscriptions/${var.subscription_id}"
  description = "Read VMSS instances and their instance view, and manage their VM extensions."

  permissions {
    actions = [
      "Microsoft.Compute/virtualMachineScaleSets/read",
      "Microsoft.Compute/virtualMachineScaleSets/virtualMachines/read",
      "Microsoft.Compute/virtualMachineScaleSets/virtualMachines/instanceView/read",
      "Microsoft.Compute/virtualMachineScaleSets/virtualMachines/extensions/read",
      "Microsoft.Compute/virtualMachineScaleSets/virtualMachines/extensions/write",
    ]
  }

  assignable_scopes = [azurerm_resource_group.lab.id]
}

resource "azurerm_role_assignment" "agent_storage_pool" {
  for_each           = data.azapi_resource.storage_pool
  scope              = each.value.id
  role_definition_id = azurerm_role_definition.agent_storage.role_definition_resource_id
  principal_id       = azurerm_user_assigned_identity.agent.principal_id
  principal_type     = "ServicePrincipal"
}

resource "azurerm_role_assignment" "agent_vmss" {
  scope              = azurerm_linux_virtual_machine_scale_set.lab.id
  role_definition_id = azurerm_role_definition.agent_vmss.role_definition_resource_id
  principal_id       = azurerm_user_assigned_identity.agent.principal_id
  principal_type     = "ServicePrincipal"
}
