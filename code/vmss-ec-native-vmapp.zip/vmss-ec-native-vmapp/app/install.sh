#!/bin/bash
# VM Application install/update command. Only lays down the agent and starts
# the service, then returns in seconds. The agent installs its own packages
# and does its ARM calls afterwards, so it never pushes an extension while this
# install is still running.
set -euo pipefail
cd "$(dirname "$0")"

install -m 0755 ec-agent.sh /usr/local/bin/ec-agent.sh
install -m 0644 ec-agent.service /etc/systemd/system/ec-agent.service
systemctl daemon-reload
systemctl enable ec-agent.service
systemctl restart --no-block ec-agent.service
