#!/bin/bash
# Everpure Cloud Azure Native per-instance volume agent (VM Application build).
#
# Runs as a systemd service on every VMSS instance. Replaces the orchestrator
# Function: the instance uses the scale set's user-assigned managed identity to
# create its own volume group and volume in its own zone's pool, pushes the
# MountIscsiLinux extension onto itself, formats and mounts the LUN, and on a
# Terminate scheduled event deletes its volume and coordinates the approval.
#
# Config comes from the scale set's userData (JSON, base64) via IMDS.
set -u

IMDS=http://169.254.169.254/metadata
ARM=https://management.azure.com
SE_API="api-version=2020-07-01"
STATE=/var/lib/ec-agent
MOUNTPOINT=/mnt/ecvol
LOG=/var/log/ec-agent.log
mkdir -p "$STATE" "$MOUNTPOINT"

log() { echo "$(date -u +%FT%TZ) $*" >> "$LOG"; }

# Dependencies are installed here rather than in the VM Application install
# step: that step runs early in boot, alongside cloud-init's own apt run, and
# collides with it. By now cloud-init can be waited on and apt retried.
ensure_deps() {
  command -v jq >/dev/null && command -v multipath >/dev/null && return 0
  cloud-init status --wait >/dev/null 2>&1 || true
  export DEBIAN_FRONTEND=noninteractive
  for attempt in $(seq 1 10); do
    apt-get -o DPkg::Lock::Timeout=300 update -y >>/var/log/ec-agent-apt.log 2>&1 &&
      apt-get -o DPkg::Lock::Timeout=300 install -y jq multipath-tools >>/var/log/ec-agent-apt.log 2>&1 && break
    log "dependency install attempt $attempt failed (see /var/log/ec-agent-apt.log), retrying"
    sleep 30
  done
  command -v jq >/dev/null && command -v multipath >/dev/null
}
ensure_deps || { log "jq/multipath-tools still missing"; exit 1; }

META=$(curl -s -H Metadata:true "$IMDS/instance?api-version=2021-02-01")
CFG=$(curl -s -H Metadata:true "$IMDS/instance/compute/userData?api-version=2021-01-01&format=text" | base64 -d)
cfg() { echo "$CFG" | jq -r "$1"; }

VMSS=$(cfg .vmss)
LOCATION=$(cfg .location)
SIZE=$(cfg .volSizeBytes)
CLIENT_ID=$(cfg .clientId)
VG_API=$(cfg .vgApi)
VOL_API=$(cfg .volApi)
MOUNT_API=$(cfg .mountApi)
COMPUTE_API=$(cfg .computeApi)

VMID=$(echo "$META" | jq -r .compute.vmId)
# Scheduled Events names instances by compute.name (e.g. myvmss_19), not the
# OS hostname (myvmss000019).
SELF=$(echo "$META" | jq -r .compute.name)
SELF_ID=$(echo "$META" | jq -r .compute.resourceId)
INSTANCE_ID=${SELF_ID##*/}
ZONE=$(echo "$META" | jq -r '.compute.zone // empty')
POOL=$(cfg ".pools[\"$ZONE\"] // empty")

KEY=$(echo "$VMID" | tr -d - | cut -c1-12)
VG="vg-$VMSS-$KEY"
VOL="vol-$VMSS-$KEY"

token() {
  curl -s -H Metadata:true \
    "$IMDS/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/&client_id=$CLIENT_ID" |
    jq -r .access_token
}

# arm METHOD URL [BODY]: URL must already carry its api-version. Prints the HTTP
# status; the response body lands in $STATE/.body.
arm() {
  local method=$1 url=$2 body=${3:-}
  local args=(-s -o "$STATE/.body" -w '%{http_code}' -X "$method" -H "Authorization: Bearer $(token)")
  [ -n "$body" ] && args+=(-H "Content-Type: application/json" -d "$body")
  curl "${args[@]}" "$url"
}

# Wait until no extension on this instance is mid-operation, so pushing the
# mount extension doesn't collide with the VM Application install.
wait_for_extensions_idle() {
  for _ in $(seq 1 60); do
    if [ "$(arm GET "$ARM$SELF_ID/instanceView?api-version=$COMPUTE_API")" = 200 ]; then
      busy=$(jq '[.extensions[]?.statuses[]?.code // empty | select(test("transitioning"; "i"))] | length' "$STATE/.body")
      [ "$busy" = 0 ] && return 0
    fi
    sleep 5
  done
  log "extensions still busy after 5 minutes, pushing anyway"
}

provision() {
  [ -f "$STATE/provisioned" ] && return 0

  if [ -z "$POOL" ]; then
    # No same-zone pool: attach nothing rather than reaching across zones.
    log "no storage pool for zone ${ZONE:-none}; skipping"
    touch "$STATE/provisioned"
    return 0
  fi

  local vg_url="$ARM$POOL/volumeGroups/$VG"
  local vol_url="$vg_url/volumes/$VOL"
  local c st

  # The RP rejects PUT on a resource that already exists, so get-or-create.
  if [ "$(arm GET "$vg_url?api-version=$VG_API")" != 200 ]; then
    body=$(jq -nc --arg loc "$LOCATION" --arg vmss "$VMSS" --arg name "$SELF" --arg iid "$INSTANCE_ID" \
      --arg vmid "$VMID" --arg zone "$ZONE" --arg pool "${POOL##*/}" \
      '{location: $loc,
        tags: {vmss: $vmss, "vm-name": $name, "instance-id": $iid, "vm-id": $vmid, zone: $zone, "storage-pool": $pool},
        properties: {performanceParameters: {}}}')
    c=$(arm PUT "$vg_url?api-version=$VG_API" "$body")
    log "create $VG in ${POOL##*/} (zone $ZONE) http=$c"
    case $c in 200 | 201) ;; *) log "$(cat "$STATE/.body")"; return 1 ;; esac
  fi
  for _ in $(seq 1 36); do
    c=$(arm GET "$vg_url?api-version=$VG_API")
    st=$(jq -r '.properties.provisioningState // empty' "$STATE/.body" 2>/dev/null)
    [ "$c" = 200 ] && [ "$st" = Succeeded ] && break
    [ "$st" = Failed ] && { log "$VG provisioning failed"; return 1; }
    sleep 5
  done

  # Volumes never report a provisioningState; a 200 means it exists.
  if [ "$(arm GET "$vol_url?api-version=$VOL_API")" != 200 ]; then
    c=$(arm PUT "$vol_url?api-version=$VOL_API" "{\"properties\":{\"provisionedSize\":$SIZE}}")
    log "create $VOL http=$c"
    case $c in 200 | 201) ;; *) log "$(cat "$STATE/.body")"; return 1 ;; esac
  fi

  c=$(arm POST "$vg_url/listConnectionParameters?api-version=$MOUNT_API" '{}')
  targets=$(jq -c '[.iscsi.endpoints[]? | {ip, port: 3260, iqn}]' "$STATE/.body" 2>/dev/null)
  if [ "$c" != 200 ] || [ -z "$targets" ] || [ "$targets" = "[]" ]; then
    log "no iSCSI endpoints (http=$c): $(cat "$STATE/.body")"
    return 1
  fi

  wait_for_extensions_idle
  ext=$(jq -nc --argjson t "$targets" '{properties: {
      publisher: "PureStorage.Extensions", type: "MountIscsiLinux", typeHandlerVersion: "1.3",
      autoUpgradeMinorVersion: true,
      settings: {targets: $t, replaceTargets: false, sessionCount: 2, reboot: false}}}')
  c=$(arm PUT "$ARM$SELF_ID/extensions/MountIscsiLinux-deploy?api-version=$COMPUTE_API" "$ext")
  log "mount extension http=$c"
  case $c in 200 | 201 | 202) touch "$STATE/provisioned" ;; *) log "$(cat "$STATE/.body")"; return 1 ;; esac
}

deprovision() {
  [ -z "$POOL" ] && return 0
  local vg_url="$ARM$POOL/volumeGroups/$VG" c1 c2
  c1=$(arm DELETE "$vg_url/volumes/$VOL?api-version=$VOL_API")
  c2=$(arm DELETE "$vg_url?api-version=$VG_API")
  log "deprovision $VOL http=$c1, $VG http=$c2"
  delete_ok "$c1" && delete_ok "$c2"
}

# Deletes are 404-safe: a retry after the VG is already gone is a success.
delete_ok() { case $1 in 200 | 202 | 204 | 404) return 0 ;; *) return 1 ;; esac; }

# How many instances in a comma-separated list still own a live volume group,
# going by the vm-name tag across every pool. A VG already Deleting counts as done.
pending_count() {
  local names=$1 n=0 url c
  for pool in $(cfg '.pools[]'); do
    url="$ARM$pool/volumeGroups?api-version=$VG_API"
    while [ -n "$url" ]; do
      c=$(arm GET "$url")
      [ "$c" = 200 ] || { echo 999; return; }
      n=$((n + $(jq --arg names "$names" '[.value[]
          | select((.tags["vm-name"] // "") as $v | ($names | split(",") | index($v)) != null)
          | select(.properties.provisioningState != "Deleting")] | length' "$STATE/.body")))
      url=$(jq -r '.nextLink // empty' "$STATE/.body")
    done
  done
  echo "$n"
}

log "agent start: $SELF zone=${ZONE:-none} pool=${POOL##*/}"

while true; do
  provision || sleep 15

  if ! mountpoint -q "$MOUNTPOINT"; then
    MPATH_DEV=$(multipath -ll 2>/dev/null | awk '/PURE,FlashArray/{print $1; exit}')
    if [ -n "$MPATH_DEV" ]; then
      DEV="/dev/mapper/$MPATH_DEV"
      blkid "$DEV" >/dev/null 2>&1 || mkfs.ext4 -F "$DEV"
      mount "$DEV" "$MOUNTPOINT" && log "mounted $DEV at $MOUNTPOINT"
    fi
  fi

  # The feed is shared across the scale set, so only act on a Terminate event
  # whose Resources array names this instance.
  EVENT=$(curl -s -H Metadata:true "$IMDS/scheduledevents?$SE_API" | jq -c --arg self "$SELF" \
    'first(.Events[]? | select(.EventType == "Terminate" and (.Resources | index($self) != null))) // empty')

  if [ -n "$EVENT" ]; then
    EID=$(echo "$EVENT" | jq -r .EventId)
    STATUS=$(echo "$EVENT" | jq -r .EventStatus)
    NAMES=$(echo "$EVENT" | jq -r '.Resources | join(",")')

    # One event can cover several instances, and approving it releases all of
    # them. Clean up once, whatever the status.
    if [ ! -f "$STATE/deprovisioned" ]; then
      log "terminate $EID status=$STATUS resources=$NAMES"
      deprovision && touch "$STATE/deprovisioned"
    fi

    # Approve only once nobody in the event still has a live volume group.
    if [ -f "$STATE/deprovisioned" ] && [ "$STATUS" = Scheduled ] && [ ! -f "$STATE/approved.$EID" ]; then
      PENDING=$(pending_count "$NAMES")
      if [ "$PENDING" = 0 ]; then
        c=$(curl -s -o /dev/null -w '%{http_code}' -X POST -H Metadata:true -H "Content-Type: application/json" \
          -d "{\"StartRequests\":[{\"EventId\":\"$EID\"}]}" "$IMDS/scheduledevents?$SE_API")
        log "approve $EID http=$c"
        [ "$c" = 200 ] && touch "$STATE/approved.$EID"
      else
        log "waiting on $PENDING instance(s) in $EID"
      fi
    fi
  fi

  sleep 5
done
