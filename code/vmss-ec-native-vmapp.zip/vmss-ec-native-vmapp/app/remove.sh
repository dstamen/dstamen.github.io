#!/bin/bash
# VM Application remove command: stops the agent. Deliberately leaves the
# volume group, volume and mount alone -- removing the app is not a scale-in.
systemctl disable --now ec-agent.service 2>/dev/null || true
rm -f /etc/systemd/system/ec-agent.service /usr/local/bin/ec-agent.sh
systemctl daemon-reload
