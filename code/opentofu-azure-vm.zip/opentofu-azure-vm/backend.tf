terraform {
  # Local state on purpose. This root is an OpenTofu test and has no backend
  # to bootstrap first. *.tfstate is gitignored at the repo root.
  #
  # To move it to Azure Blob later, swap this block for the one below and run
  # `tofu init -migrate-state`.
  #
  # backend "azurerm" {
  #   resource_group_name  = "<state-rg>"
  #   storage_account_name = "<state-sa>"
  #   container_name       = "tfstate"
  #   key                  = "tofu-simple-vm.tfstate"
  # }
  backend "local" {}
}
