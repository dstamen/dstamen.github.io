# OpenTofu Azure VM

A resource group, VNet, subnet, NSG, public IP and an Ubuntu 24.04 VM, deployed with OpenTofu and local state.

```sh
cp terraform.auto.tfvars.example terraform.auto.tfvars   # fill in your values
tofu init
tofu plan -out=tfplan
tofu apply tfplan
```

Tear it down with `tofu destroy`.
