variable "subscription_id" {
  type = string
}

variable "resource_group" {
  type = string
}

variable "location" {
  type    = string
  default = "westus2"
}

# --- Network ---

variable "vnet_address_space" {
  type    = string
  default = "10.60.0.0/16"
}

variable "subnet_prefix" {
  type    = string
  default = "10.60.1.0/24"
}

variable "ssh_source_cidr" {
  type        = string
  description = "CIDR allowed to SSH to the VM's public IP. Set to your egress IP /32."
}

# --- VM ---

variable "vm_name" {
  type = string
}

variable "vm_size" {
  type    = string
  default = "Standard_B2s"
}

variable "admin_username" {
  type    = string
  default = "azureuser"
}

variable "ssh_public_key_path" {
  type        = string
  description = "Path to the SSH public key file to authorize on the VM."
  default     = "~/.ssh/id_rsa.pub"
}

variable "tags" {
  type    = map(string)
  default = {}
}
