#!/bin/bash
set -euo pipefail

apt-get update -y
apt-get install -y jq multipath-tools

IMDS="http://169.254.169.254/metadata"
FUNC_URL="${func_base_url}"
SECRET="${shared_secret}"

META=$(curl -s -H "Metadata:true" "$IMDS/instance?api-version=2021-02-01")
VMID=$(echo "$META" | jq -r '.compute.vmId')
RESOURCE_ID=$(echo "$META" | jq -r '.compute.resourceId')
INSTANCE_ID=$(basename "$RESOURCE_ID")
# Scheduled Events' Resources array names VMs by their ARM resource name
# (compute.name, e.g. "myvmss_19"), not the OS hostname
# ("myvmss000019") -- those are two different strings, and matching
# against hostname here means the filter below never matches anything.
SELF_NAME=$(echo "$META" | jq -r '.compute.name')
echo "$VMID" > /var/log/ec-vmid

# This creates the VolumeGroup/Volume and pushes the vendor MountIscsiLinux
# extension onto this instance via ARM. The extension only establishes the
# iSCSI sessions and lets multipathd claim the LUN -- it does not create a
# filesystem or mount it anywhere, so the agent below does that part.
curl -s -X POST -H "x-shared-secret: $SECRET" \
  "$FUNC_URL/api/provision?vmId=$VMID&instanceId=$INSTANCE_ID" \
  > /var/log/ec-provision.json

cat > /etc/ec-agent.env << EOF
FUNC_URL="$FUNC_URL"
SECRET="$SECRET"
VMID="$VMID"
SELF="$SELF_NAME"
EOF
chmod 600 /etc/ec-agent.env

cat > /usr/local/bin/ec-agent.sh << 'EOS'
#!/bin/bash
source /etc/ec-agent.env
IMDS="http://169.254.169.254/metadata"
SE_API="api-version=2020-07-01"
MOUNTPOINT=/mnt/ecvol
DONE=/var/lib/ec-agent/deprovisioned
mkdir -p "$MOUNTPOINT" /var/lib/ec-agent

log() {
  echo "$(date -u +%FT%TZ) $*" >> /var/log/ec-agent.log
}

while true; do
  if ! mountpoint -q "$MOUNTPOINT"; then
    MPATH_DEV=$(multipath -ll 2>/dev/null | awk '/PURE,FlashArray/{print $1; exit}')
    if [ -n "$MPATH_DEV" ]; then
      DEV="/dev/mapper/$MPATH_DEV"
      blkid "$DEV" >/dev/null 2>&1 || mkfs.ext4 -F "$DEV"
      mount "$DEV" "$MOUNTPOINT" && log "mounted $DEV at $MOUNTPOINT"
    fi
  fi

  # The feed is shared across the scale set, so only act on a Terminate
  # event whose Resources array names this instance.
  EVENT=$(curl -s -H "Metadata:true" "$IMDS/scheduledevents?$SE_API" | jq -c --arg self "$SELF" \
    'first(.Events[] | select(.EventType=="Terminate" and (.Resources | index($self) != null))) // empty')

  if [ -n "$EVENT" ]; then
    EID=$(echo "$EVENT" | jq -r '.EventId')
    STATUS=$(echo "$EVENT" | jq -r '.EventStatus')
    NAMES=$(echo "$EVENT" | jq -r '.Resources | join(",")')

    # One event can cover several instances, and approving it releases all
    # of them. Clean up once, whatever the status -- a sibling may already
    # have approved it (status Started) and this instance is on the clock.
    if [ ! -f "$DONE" ]; then
      log "terminate $EID status=$STATUS resources=$NAMES"
      CODE=$(curl -s -o /var/log/ec-deprovision.json -w '%%{http_code}' -X POST \
        -H "x-shared-secret: $SECRET" "$FUNC_URL/api/deprovision?vmId=$VMID")
      log "deprovision http=$CODE"
      [ "$CODE" = "200" ] && touch "$DONE"
    fi

    # Only approve once every instance in the event has cleaned up, so this
    # instance doesn't release a sibling that hasn't. If nobody approves,
    # Azure proceeds on its own when the notification timeout runs out.
    if [ -f "$DONE" ] && [ "$STATUS" = "Scheduled" ] && [ ! -f "$DONE.$EID" ]; then
      PENDING=$(curl -s -H "x-shared-secret: $SECRET" "$FUNC_URL/api/pending?vmNames=$NAMES" | jq -r '.pending | length')
      if [ "$PENDING" = "0" ]; then
        CODE=$(curl -s -o /dev/null -w '%%{http_code}' -X POST -H "Metadata:true" -H "Content-Type: application/json" \
          -d "{\"StartRequests\":[{\"EventId\":\"$EID\"}]}" "$IMDS/scheduledevents?$SE_API")
        log "approve $EID http=$CODE"
        [ "$CODE" = "200" ] && touch "$DONE.$EID"
      else
        log "waiting on $PENDING instance(s) in $EID"
      fi
    fi
  fi

  sleep 5
done
EOS
chmod +x /usr/local/bin/ec-agent.sh

cat > /etc/systemd/system/ec-agent.service << 'EOF'
[Unit]
Description=EC native volume mount + termination watcher
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/ec-agent.sh
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now ec-agent.service
