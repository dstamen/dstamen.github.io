import json
import logging
import os
import time

import azure.functions as func
import requests
from azure.identity import DefaultAzureCredential

app = func.FunctionApp()

ARM = "https://management.azure.com"
COMPUTE_API = "2024-07-01"
POOLS_BY_ZONE = json.loads(os.environ["STORAGE_POOL_IDS_BY_ZONE"])
LOCATION = os.environ["LOCATION"]
VG_API = os.environ["VOLUME_GROUP_API_VERSION"]
VOL_API = os.environ["VOLUME_API_VERSION"]
MOUNT_API = os.environ["MOUNT_DATA_API_VERSION"]
VOL_SIZE_BYTES = int(os.environ["VOL_SIZE_BYTES"])
VMSS_NAME = os.environ["VMSS_NAME"]
VMSS_ID = os.environ["VMSS_ID"]
SHARED_SECRET = os.environ["SHARED_SECRET"]

_credential = DefaultAzureCredential()


def _token() -> str:
    return _credential.get_token(f"{ARM}/.default").token


def _headers() -> dict:
    return {"Authorization": f"Bearer {_token()}", "Content-Type": "application/json"}


def _wait_succeeded(url: str, api_version: str, attempts: int = 18, delay: int = 5) -> dict:
    for _ in range(attempts):
        resp = requests.get(url, params={"api-version": api_version}, headers=_headers())
        if resp.status_code == 404:
            time.sleep(delay)
            continue
        resp.raise_for_status()
        body = resp.json()
        props = body.get("properties", {})
        if "provisioningState" not in props:
            # Volumes don't report a provisioningState at all -- creation is
            # synchronous, so a 200 with a body (e.g. a serialNumber) means done.
            return body
        state = props["provisioningState"]
        if state == "Succeeded":
            return body
        if state == "Failed":
            raise RuntimeError(f"{url} provisioning failed: {body}")
        time.sleep(delay)
    raise TimeoutError(f"{url} did not reach Succeeded in time")


def _names(vm_id: str) -> tuple[str, str]:
    # vm_id is the instance's own IMDS compute.vmId (a GUID) -- short and
    # unique per instance for the life of that instance, so it works fine as
    # a naming key even though it isn't the ARM-path numeric instanceId.
    key = vm_id.replace("-", "")[:12]
    return f"vg-{VMSS_NAME}-{key}", f"vol-{VMSS_NAME}-{key}"


def _authorized(req: func.HttpRequest) -> bool:
    return req.headers.get("x-shared-secret") == SHARED_SECRET


def _exists(url: str, api_version: str) -> bool:
    resp = requests.get(url, params={"api-version": api_version}, headers=_headers())
    return resp.status_code == 200


def _instance_url(instance_id: str) -> str:
    return f"{ARM}{VMSS_ID}/virtualMachines/{instance_id}"


def _instance_zone(instance_id: str) -> str | None:
    # Read the zone from ARM rather than trusting one the caller sends.
    resp = requests.get(_instance_url(instance_id), params={"api-version": COMPUTE_API}, headers=_headers())
    resp.raise_for_status()
    zones = resp.json().get("zones") or []
    return zones[0] if zones else None


def _create_volume_group_and_volume(pool_id: str, vm_id: str, zone: str, instance_id: str) -> dict:
    vg_name, vol_name = _names(vm_id)
    vg_url = f"{ARM}{pool_id}/volumeGroups/{vg_name}"

    # The RP rejects PUT on a resource that already exists (400
    # ResourceCreationValidateFailed), so this has to be get-or-create, not
    # a blind PUT -- a retried/duplicate boot call must not fail here.
    if not _exists(vg_url, VG_API):
        put = requests.put(
            vg_url,
            params={"api-version": VG_API},
            headers=_headers(),
            json={
                "location": LOCATION,
                # Uniform VMSS instances can't hold their own tags, so the VG
                # carries the instance -> zone -> pool mapping instead.
                "tags": {
                    "vmss": VMSS_NAME,
                    "vm-name": f"{VMSS_NAME}_{instance_id}",
                    "instance-id": instance_id,
                    "vm-id": vm_id,
                    "zone": zone,
                    "storage-pool": pool_id.rstrip("/").split("/")[-1],
                },
                "properties": {"performanceParameters": {}},
            },
        )
        if put.status_code not in (200, 201):
            put.raise_for_status()
    _wait_succeeded(vg_url, VG_API)

    vol_url = f"{vg_url}/volumes/{vol_name}"
    if not _exists(vol_url, VOL_API):
        put = requests.put(
            vol_url,
            params={"api-version": VOL_API},
            headers=_headers(),
            json={"properties": {"provisionedSize": VOL_SIZE_BYTES}},
        )
        if put.status_code not in (200, 201):
            put.raise_for_status()
    _wait_succeeded(vol_url, VOL_API)

    conn = requests.post(
        f"{vg_url}/listConnectionParameters",
        params={"api-version": MOUNT_API},
        headers=_headers(),
    )
    conn.raise_for_status()
    return conn.json()


def _mount_on_instance(instance_id: str, endpoints: list[dict]) -> None:
    ext_url = f"{_instance_url(instance_id)}/extensions/MountIscsiLinux-deploy"
    targets = [{"ip": e["ip"], "port": 3260, "iqn": e["iqn"]} for e in endpoints]
    body = {
        "properties": {
            "publisher": "PureStorage.Extensions",
            "type": "MountIscsiLinux",
            "typeHandlerVersion": "1.3",
            "autoUpgradeMinorVersion": True,
            "settings": {
                "targets": targets,
                "replaceTargets": False,
                "sessionCount": 2,
                "reboot": False,  # Linux iscsid doesn't need a restart to pick up new targets; that's a Windows-only requirement
            },
        }
    }
    put = requests.put(ext_url, params={"api-version": COMPUTE_API}, headers=_headers(), json=body)
    if put.status_code not in (200, 201, 202):
        put.raise_for_status()
    logging.info("Mount extension submitted for instance %s: %s", instance_id, put.status_code)


def _delete_volume_and_group(vm_id: str) -> None:
    # Deprovision only gets a vmId, so sweep every pool. Deletes are 404-safe,
    # and this still works if the instance's zone can't be read mid-termination.
    vg_name, vol_name = _names(vm_id)
    for pool_id in POOLS_BY_ZONE.values():
        vg_url = f"{ARM}{pool_id}/volumeGroups/{vg_name}"
        for url, api in ((f"{vg_url}/volumes/{vol_name}", VOL_API), (vg_url, VG_API)):
            resp = requests.delete(url, params={"api-version": api}, headers=_headers())
            if resp.status_code not in (200, 202, 204, 404):
                resp.raise_for_status()
    logging.info("Deleted volume %s and volume group %s", vol_name, vg_name)


def _pending_vm_names(vm_names: set[str]) -> list[str]:
    # Which of these instances still have a live VolumeGroup, going by the
    # vm-name tag. A VG that's already Deleting counts as done: the delete
    # has been issued and doesn't need the instance to stay up for it.
    pending = []
    for pool_id in POOLS_BY_ZONE.values():
        url = f"{ARM}{pool_id}/volumeGroups"
        params = {"api-version": VG_API}
        while url:
            resp = requests.get(url, params=params, headers=_headers())
            resp.raise_for_status()
            body = resp.json()
            for vg in body.get("value", []):
                name = (vg.get("tags") or {}).get("vm-name")
                state = vg.get("properties", {}).get("provisioningState")
                if name in vm_names and state != "Deleting":
                    pending.append(name)
            url, params = body.get("nextLink"), None
    return pending


@app.function_name(name="pending")
@app.route(route="pending", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def pending(req: func.HttpRequest) -> func.HttpResponse:
    if not _authorized(req):
        return func.HttpResponse("unauthorized", status_code=401)

    names = {n for n in (req.params.get("vmNames") or "").split(",") if n}
    if not names:
        return func.HttpResponse("missing vmNames", status_code=400)

    try:
        left = _pending_vm_names(names)
    except Exception as exc:
        logging.exception("Pending check failed for %s", names)
        return func.HttpResponse(f"pending check failed: {exc}", status_code=500)

    return func.HttpResponse(json.dumps({"pending": left}), mimetype="application/json", status_code=200)


@app.function_name(name="provision")
@app.route(route="provision", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
def provision(req: func.HttpRequest) -> func.HttpResponse:
    if not _authorized(req):
        return func.HttpResponse("unauthorized", status_code=401)

    vm_id = req.params.get("vmId")
    instance_id = req.params.get("instanceId")
    if not vm_id or not instance_id:
        return func.HttpResponse("missing vmId or instanceId", status_code=400)

    try:
        zone = _instance_zone(instance_id) or "none"
        pool_id = POOLS_BY_ZONE.get(zone)

        if not pool_id:
            # No same-zone pool: attach nothing rather than reaching across zones.
            logging.warning("No storage pool for zone %s (instance %s); skipping", zone, instance_id)
            return func.HttpResponse(f"no storage pool for zone {zone}; skipped", status_code=200)

        vg_name, _ = _names(vm_id)
        pool_name = pool_id.rstrip("/").split("/")[-1]

        logging.info("Provisioning %s in pool %s (zone %s) for instance %s", vg_name, pool_name, zone, instance_id)
        conn_params = _create_volume_group_and_volume(pool_id, vm_id, zone, instance_id)
        endpoints = conn_params.get("iscsi", {}).get("endpoints", [])
        if not endpoints:
            raise RuntimeError(f"no iSCSI endpoints returned: {conn_params}")
        _mount_on_instance(instance_id, endpoints)
    except Exception as exc:
        logging.exception("Provisioning failed for vmId=%s", vm_id)
        return func.HttpResponse(f"provisioning failed: {exc}", status_code=500)

    return func.HttpResponse("ok", status_code=200)


@app.function_name(name="deprovision")
@app.route(route="deprovision", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
def deprovision(req: func.HttpRequest) -> func.HttpResponse:
    if not _authorized(req):
        return func.HttpResponse("unauthorized", status_code=401)

    vm_id = req.params.get("vmId")
    if not vm_id:
        return func.HttpResponse("missing vmId", status_code=400)

    logging.info("Deprovisioning volume for vmId=%s", vm_id)
    try:
        _delete_volume_and_group(vm_id)
    except Exception as exc:
        logging.exception("Deprovisioning failed for vmId=%s", vm_id)
        return func.HttpResponse(f"deprovisioning failed: {exc}", status_code=500)

    return func.HttpResponse("ok", status_code=200)
