# Least-privilege custom roles for the Function's managed identity, scoped to
# each pool and to the one VMSS -- not the resource group or subscription.

locals {
  pool_rg_ids = distinct([
    for pool in var.storage_pools_by_zone : "/subscriptions/${var.subscription_id}/resourceGroups/${pool.resource_group}"
  ])
}

# Everything the Function does against a pool: get-or-create, list and delete
# volume groups and volumes, and read the iSCSI connection parameters.
resource "azurerm_role_definition" "orch_storage" {
  name        = "EC native volume orchestrator (${var.vmss_name})"
  scope       = "/subscriptions/${var.subscription_id}"
  description = "Create, read and delete Everpure Cloud Azure Native volume groups and volumes in a storage pool."

  permissions {
    actions = [
      "PureStorage.Block/storagePools/read",
      "PureStorage.Block/storagePools/volumeGroups/read",
      "PureStorage.Block/storagePools/volumeGroups/write",
      "PureStorage.Block/storagePools/volumeGroups/delete",
      "PureStorage.Block/storagePools/volumeGroups/listConnectionParameters/action",
      "PureStorage.Block/storagePools/volumeGroups/volumes/read",
      "PureStorage.Block/storagePools/volumeGroups/volumes/write",
      "PureStorage.Block/storagePools/volumeGroups/volumes/delete",
    ]
  }

  assignable_scopes = local.pool_rg_ids
}

# Everything the Function does against the scale set: read an instance's zone
# and push the vendor MountIscsiLinux extension onto it.
resource "azurerm_role_definition" "orch_vmss" {
  name        = "EC native VMSS extension orchestrator (${var.vmss_name})"
  scope       = "/subscriptions/${var.subscription_id}"
  description = "Read VMSS instances and manage their VM extensions."

  permissions {
    actions = [
      "Microsoft.Compute/virtualMachineScaleSets/read",
      "Microsoft.Compute/virtualMachineScaleSets/virtualMachines/read",
      "Microsoft.Compute/virtualMachineScaleSets/virtualMachines/extensions/read",
      "Microsoft.Compute/virtualMachineScaleSets/virtualMachines/extensions/write",
    ]
  }

  assignable_scopes = [data.azurerm_resource_group.lab.id]
}

resource "azurerm_role_assignment" "orch_storage_pool" {
  for_each           = data.azapi_resource.storage_pool
  scope              = each.value.id
  role_definition_id = azurerm_role_definition.orch_storage.role_definition_resource_id
  principal_id       = azurerm_function_app_flex_consumption.orchestrator.identity[0].principal_id
}

resource "azurerm_role_assignment" "orch_vmss" {
  scope              = azurerm_linux_virtual_machine_scale_set.lab.id
  role_definition_id = azurerm_role_definition.orch_vmss.role_definition_resource_id
  principal_id       = azurerm_function_app_flex_consumption.orchestrator.identity[0].principal_id
}
