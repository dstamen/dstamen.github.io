data "azurerm_resource_group" "lab" {
  name = var.resource_group
}

data "azurerm_virtual_network" "core" {
  name                = var.vnet_name
  resource_group_name = var.vnet_resource_group
}

data "azurerm_subnet" "default" {
  name                 = var.subnet_name
  virtual_network_name = data.azurerm_virtual_network.core.name
  resource_group_name  = var.vnet_resource_group
}

# One existing EC native StoragePool per zone. Each instance gets its
# VolumeGroup/Volume from the pool in its own zone.
data "azapi_resource" "storage_pool" {
  for_each  = var.storage_pools_by_zone
  type      = "PureStorage.Block/storagePools@2024-11-01-preview"
  name      = each.value.name
  parent_id = "/subscriptions/${var.subscription_id}/resourceGroups/${each.value.resource_group}"
}
