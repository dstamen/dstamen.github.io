resource "random_string" "sa_suffix" {
  length  = 6
  special = false
  upper   = false
}

# Lab-only auth: instances present this on the provision/deprovision calls.
# Good enough for a throwaway RG; a real deployment would use the VMSS's own
# managed identity against Easy Auth / AAD instead of a shared secret baked
# into custom_data.
resource "random_password" "shared_secret" {
  length  = 32
  special = false
}

resource "azurerm_storage_account" "func" {
  name                     = "stvmssec${random_string.sa_suffix.result}"
  resource_group_name      = data.azurerm_resource_group.lab.name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = var.tags
}

# Flex Consumption (FC1). Linux Consumption (Y1) is legacy and has no quota
# in some regions (no quota in the region I tested in), Flex is its replacement.
resource "azurerm_storage_container" "func_deploy" {
  name                  = "function-deploy"
  storage_account_id    = azurerm_storage_account.func.id
  container_access_type = "private"
}

resource "azurerm_service_plan" "func" {
  name                = "${var.vmss_name}-orch-plan"
  resource_group_name = data.azurerm_resource_group.lab.name
  location            = var.location
  os_type             = "Linux"
  sku_name            = "FC1"
  tags                = var.tags
}

resource "azurerm_function_app_flex_consumption" "orchestrator" {
  name                = "${var.vmss_name}-orch"
  resource_group_name = data.azurerm_resource_group.lab.name
  location            = var.location
  tags                = var.tags
  service_plan_id     = azurerm_service_plan.func.id

  storage_container_type      = "blobContainer"
  storage_container_endpoint  = "${azurerm_storage_account.func.primary_blob_endpoint}${azurerm_storage_container.func_deploy.name}"
  storage_authentication_type = "StorageAccountConnectionString"
  storage_access_key          = azurerm_storage_account.func.primary_access_key

  runtime_name           = "python"
  runtime_version        = "3.11"
  instance_memory_in_mb  = 2048
  maximum_instance_count = 40

  identity {
    type = "SystemAssigned"
  }

  site_config {}

  app_settings = {
    "STORAGE_POOL_IDS_BY_ZONE" = jsonencode({ for zone, pool in data.azapi_resource.storage_pool : zone => pool.id })
    "LOCATION"                 = var.location
    "VOLUME_GROUP_API_VERSION" = "2026-01-01-preview"
    "VOLUME_API_VERSION"       = "2026-05-01-preview"
    "MOUNT_DATA_API_VERSION"   = "2026-05-01-preview"
    "VOL_SIZE_BYTES"           = tostring(var.vol_size_bytes)
    "VMSS_NAME"                = var.vmss_name
    "VMSS_ID"                  = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group}/providers/Microsoft.Compute/virtualMachineScaleSets/${var.vmss_name}"
    "SHARED_SECRET"            = random_password.shared_secret.result
  }
}

output "function_app_name" {
  value = azurerm_function_app_flex_consumption.orchestrator.name
}

output "function_app_identity_principal_id" {
  value = azurerm_function_app_flex_consumption.orchestrator.identity[0].principal_id
}
