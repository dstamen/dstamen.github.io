resource "azurerm_linux_virtual_machine_scale_set" "lab" {
  name                = var.vmss_name
  resource_group_name = data.azurerm_resource_group.lab.name
  location            = var.location
  sku                 = var.vm_size
  instances           = var.instance_count
  upgrade_mode        = "Manual"
  zones               = var.zones
  tags                = var.tags

  admin_username = var.admin_username
  admin_ssh_key {
    username   = var.admin_username
    public_key = var.admin_ssh_public_key
  }
  disable_password_authentication = true

  custom_data = base64encode(templatefile("${path.module}/templates/vmss_bootstrap.sh.tpl", {
    func_base_url = "https://${azurerm_function_app_flex_consumption.orchestrator.default_hostname}"
    shared_secret = random_password.shared_secret.result
  }))

  termination_notification {
    enabled = true
    timeout = "PT5M"
  }

  boot_diagnostics {
    storage_account_uri = null # managed storage account (recommended)
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }

  os_disk {
    storage_account_type = "StandardSSD_LRS" # Standard HDD is retiring Sept 2028 -- don't reach for it on new disks
    caching              = "ReadWrite"
  }

  network_interface {
    name    = "${var.vmss_name}-nic"
    primary = true

    ip_configuration {
      name      = "internal"
      primary   = true
      subnet_id = data.azurerm_subnet.default.id
    }
  }

  # Scaling is done by hand (or autoscale), not by Terraform.
  lifecycle {
    ignore_changes = [instances]
  }
}

output "vmss_id" {
  value = azurerm_linux_virtual_machine_scale_set.lab.id
}
