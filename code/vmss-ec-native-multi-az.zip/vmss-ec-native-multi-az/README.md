# VMSS + Everpure Cloud Azure Native, multi-AZ

Proof of concept, not an officially supported pattern.

- `infra/`  VNet, NAT gateway, Bastion, one delegated subnet and one storage pool per availability zone
- `vmss/`   the zonal VMSS, the Flex Consumption Function, and the per-instance boot agent

Apply `infra/` first (pools take ~30 minutes), then `vmss/`. Copy each
`terraform.auto.tfvars.example` to `terraform.auto.tfvars` and fill it in.
Deploy the Function code after `vmss/` applies:

    cd vmss/function_app && zip -r ../function_app.zip . && cd ..
    az functionapp deployment source config-zip --name <vmss_name>-orch \
      --resource-group <rg> --src function_app.zip --build-remote true
