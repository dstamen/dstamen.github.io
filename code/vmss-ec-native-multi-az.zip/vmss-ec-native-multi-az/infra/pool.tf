resource "azapi_resource" "storage_pool" {
  for_each = var.storage_pools

  type                      = "PureStorage.Block/storagePools@${local.pool_api_version}"
  name                      = each.value.name
  location                  = var.location
  parent_id                 = azurerm_resource_group.rg.id
  tags                      = var.tags
  schema_validation_enabled = true

  body = {
    properties = {
      availabilityZone             = each.key
      provisionedBandwidthMbPerSec = each.value.bandwidth
      reservationResourceId        = var.reservation_id
      vnetInjection = {
        subnetId = azurerm_subnet.storage[each.key].id
        vnetId   = azurerm_virtual_network.vnet.id
      }
    }
  }

  timeouts {
    create = "90m"
    update = "90m"
    delete = "90m"
    read   = "5m"
  }

  lifecycle {
    ignore_changes = [tags]
  }
}
