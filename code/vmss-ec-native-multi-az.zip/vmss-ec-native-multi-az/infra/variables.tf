variable "subscription_id" {
  type        = string
  description = "Azure subscription ID"
}

variable "resource_group" {
  type        = string
  description = "Resource group for the network and storage pools"
}

variable "location" {
  type        = string
  description = "Azure region with availability zones (e.g. eastus2)"
}

variable "prefix" {
  type        = string
  description = "Name prefix for the network resources"
}

variable "vnet_cidr" {
  type = string
}

variable "vm_subnet_cidr" {
  type        = string
  description = "Subnet for the VMSS instances. Gets the NAT gateway for outbound."
}

variable "bastion_subnet_cidr" {
  type        = string
  description = "AzureBastionSubnet, /26 or larger"
}

variable "reservation_id" {
  type        = string
  description = "Full resource ID of the Everpure Cloud reservation"
}

variable "storage_pools" {
  type = map(object({
    name        = string
    subnet_cidr = string
    bandwidth   = number
  }))
  description = "One pool per availability zone, keyed by zone. Each gets its own delegated subnet."
}

variable "tags" {
  type    = map(string)
  default = {}
}
