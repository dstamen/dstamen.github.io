output "vnet_id" {
  value = azurerm_virtual_network.vnet.id
}

output "vm_subnet_id" {
  value = azurerm_subnet.vm.id
}

output "storage_pool_ids_by_zone" {
  value = { for zone, pool in azapi_resource.storage_pool : zone => pool.id }
}

output "bastion_name" {
  value = azurerm_bastion_host.bastion.name
}
