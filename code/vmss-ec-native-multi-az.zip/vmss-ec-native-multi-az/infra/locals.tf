locals {
  # Pinned to what created the pools -- the PureStorage.Block RP rejects PUT
  # on an existing resource after an api-version jump.
  pool_api_version = "2024-11-01-preview"

  rg_id = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group}"
}
