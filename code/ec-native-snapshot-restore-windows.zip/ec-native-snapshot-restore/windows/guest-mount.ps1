# Runs inside the Windows guest via Run Command (RunPowerShellScript). Rescans
# storage, finds the restored Everpure volume by serial, brings it online and
# mounts it.
#
# Run Command passes --parameters by name:
#   NewSerial  serial of the restored volume
#   SrcSerial  serial of the source volume (reported for context)
#   MountPath  "auto" for the next free drive letter, a letter like "R:", or an
#              empty NTFS folder like "C:\restored\data1"
#   Mode       "ro" to mount read-only, "rw" otherwise
param(
  [string]$NewSerial,
  [string]$SrcSerial,
  [string]$MountPath = "auto",
  [string]$Mode = "rw"
)
$ErrorActionPreference = "Stop"

function Fail($msg) { Write-Output "RESTORE_ERROR: $msg"; exit 1 }

# Run Command passes these as -Name value, so a value can't start with "-".
$NewSerial = $NewSerial.ToUpper()
$SrcSerial = $SrcSerial.ToUpper()

# The clone lives in the volume group this VM is already logged in to, so a
# storage rescan is enough to surface it. No extension change needed.
$disk = $null
for ($i = 0; $i -lt 24 -and -not $disk; $i++) {
  Update-HostStorageCache
  $disk = Get-Disk | Where-Object SerialNumber -eq $NewSerial
  if (-not $disk) { Start-Sleep 5 }
}
if (-not $disk) { Fail "restored volume (serial $NewSerial) did not appear after rescan" }
Write-Output "restored disk: $($disk.Number)"

# MPIO reports the LUN by NAA id, 624A9370 + serial. Don't touch a disk with
# no live path; I/O to it just waits on the path timeouts.
$mpio = Get-CimInstance -Namespace root/wmi -ClassName MPIO_DISK_INFO -ErrorAction SilentlyContinue |
  ForEach-Object { $_.DriveInfo } | Where-Object { $_.SerialNumber.Trim() -eq "624A9370$NewSerial" }
if ($mpio) {
  if ($mpio.NumberPaths -lt 1) { Fail "disk $($disk.Number) has no MPIO paths" }
  Write-Output "mpio paths: $($mpio.NumberPaths)"
}

$src = Get-Disk | Where-Object SerialNumber -eq $SrcSerial
if ($src) {
  $srcLetters = (Get-Partition -DiskNumber $src.Number | Where-Object DriveLetter).DriveLetter -join ","
  Write-Output "source disk: $($src.Number) ($srcLetters)"
}

# A clone carries the source's disk GUID (GPT) or signature (MBR). Windows
# keeps a colliding disk offline, and bringing it online writes a new one.
# Set read-only first so nothing on the clone changes after it comes up.
if ($Mode -eq "ro") { Set-Disk -Number $disk.Number -IsReadOnly $true }
if ($disk.IsOffline) {
  $before = $disk.Guid
  $reason = $disk.OfflineReason
  if ($Mode -eq "ro") {
    # A read-only disk can't take a new GUID, so let it come online writable
    # for the rewrite, then put read-only back.
    Set-Disk -Number $disk.Number -IsReadOnly $false
    Set-Disk -Number $disk.Number -IsOffline $false
    Set-Disk -Number $disk.Number -IsReadOnly $true
  } else {
    Set-Disk -Number $disk.Number -IsOffline $false
  }
  $disk = Get-Disk -Number $disk.Number
  Write-Output "brought online (offline reason: $reason); guid $before -> $($disk.Guid)"
}

# Dynamic disks and Storage Spaces are the Windows version of the LVM case:
# the clone collides with the source pool or disk group.
$parts = Get-Partition -DiskNumber $disk.Number
if ($parts | Where-Object { $_.Type -match "LDM|Spaces|Unknown" }) {
  Fail "disk $($disk.Number) is a dynamic disk or Storage Spaces member. Import it by hand"
}
$part = $parts | Where-Object { $_.Type -in "Basic", "IFS" } | Sort-Object Size -Descending | Select-Object -First 1
if (-not $part) { Fail "no data partition on disk $($disk.Number)" }

$vol = $part | Get-Volume
if ($vol.FileSystem -eq "Unknown" -or -not $vol.FileSystem) {
  Fail "partition $($part.PartitionNumber) has no readable filesystem (BitLocker locked?)"
}

# Windows may already have given the partition a letter when it came online.
if ($MountPath -eq "auto") {
  if (-not $part.DriveLetter) {
    Add-PartitionAccessPath -DiskNumber $disk.Number -PartitionNumber $part.PartitionNumber -AssignDriveLetter
    $part = Get-Partition -DiskNumber $disk.Number -PartitionNumber $part.PartitionNumber
  }
  $where = "$($part.DriveLetter):\"
} else {
  if ($part.DriveLetter) {
    Remove-PartitionAccessPath -DiskNumber $disk.Number -PartitionNumber $part.PartitionNumber -AccessPath "$($part.DriveLetter):\"
  }
  if ($MountPath -match '^[A-Za-z]:?$') {
    $letter = $MountPath.Substring(0, 1).ToUpper()
    if (Get-Volume -DriveLetter $letter -ErrorAction SilentlyContinue) { Fail "drive $letter is already in use" }
    Set-Partition -DiskNumber $disk.Number -PartitionNumber $part.PartitionNumber -NewDriveLetter $letter
    $where = "${letter}:\"
  } else {
    if (-not (Test-Path $MountPath)) { New-Item -ItemType Directory -Path $MountPath | Out-Null }
    if (Get-ChildItem $MountPath -Force) { Fail "$MountPath is not empty" }
    Add-PartitionAccessPath -DiskNumber $disk.Number -PartitionNumber $part.PartitionNumber -AccessPath $MountPath
    $where = $MountPath
  }
}

$ro = (Get-Disk -Number $disk.Number).IsReadOnly
Write-Output "mounted disk $($disk.Number) partition $($part.PartitionNumber) at $where ($($vol.FileSystem), $(if ($ro) {'read-only'} else {'read-write'}))"
Write-Output "RESTORE_OK $($disk.Number) $where"
