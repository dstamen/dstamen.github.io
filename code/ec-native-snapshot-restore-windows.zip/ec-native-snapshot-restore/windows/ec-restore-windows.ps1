#!/usr/bin/env pwsh
# Restore one Everpure Cloud Azure Native volume from its latest snapshot and
# mount it next to the original on a Windows VM.
#
#   VM name -> volume group of the same name (searched across storage pools)
#   latest volume group snapshot that contains the volume
#   clone that member snapshot to <volume>-restored in the same volume group
#   Run Command on the guest: rescan, bring the disk online, mount it
#
# Needs: PowerShell 7 and az (logged in). Runs on Windows, macOS or Linux.
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ResourceGroup,
  [Parameter(Mandatory)][string]$VmName,
  [Parameter(Mandatory)][string]$Volume,
  # "auto" for the next free drive letter, a letter like "R:", or an empty folder
  [string]$MountPath = "auto",
  [string]$Snapshot,
  [string]$Pool,
  [string]$Suffix = "-restored",
  [switch]$ReadOnly,
  [switch]$DryRun
)
$ErrorActionPreference = "Stop"

$VgApi = "2026-05-01-preview"
$VolApi = "2026-05-01-preview"
$SnapApi = "2026-05-01-preview"
$Arm = "https://management.azure.com"
$NewVol = "$Volume$Suffix"
$Mode = if ($ReadOnly) { "ro" } else { "rw" }

function Log($msg) { Write-Host "==> $msg" }
function Die($msg) { Write-Host "ERROR: $msg" -ForegroundColor Red; exit 1 }

# az wrapper: returns parsed JSON, or $null on a non-zero exit (404 and friends).
function AzJson {
  $out = & (Get-Command az -CommandType Application | Select-Object -First 1) @args --only-show-errors 2>$null
  if ($LASTEXITCODE -ne 0) { return $null }
  if ($out) { return ($out | Out-String | ConvertFrom-Json) }
}
function ArmGet($path) { AzJson rest --method get --url "$Arm$path" }

# --- VM ---
$vm = AzJson vm show -g $ResourceGroup -n $VmName
if (-not $vm) { Die "VM $ResourceGroup/$VmName not found" }
if ($vm.storageProfile.osDisk.osType -ne "Windows") { Die "$VmName is $($vm.storageProfile.osDisk.osType); use ec-restore.sh for Linux" }
$power = (AzJson vm get-instance-view -g $ResourceGroup -n $VmName).instanceView.statuses |
  Where-Object code -like "PowerState/*" | Select-Object -ExpandProperty code
if ($power -ne "PowerState/running") { Die "$VmName is $power; Run Command needs it running" }

# --- volume group (same name as the VM) ---
$pools = if ($Pool) { @($Pool) } else { @(AzJson resource list --resource-type PureStorage.Block/storagePools --query "[].id") }
$vgId = $null
foreach ($p in $pools) {
  if (ArmGet "$p/volumeGroups/$VmName`?api-version=$VgApi") { $vgId = "$p/volumeGroups/$VmName"; break }
}
if (-not $vgId) { Die "no volume group named $VmName in: $($pools -join ', ')" }
Log "volume group: $vgId"

$src = ArmGet "$vgId/volumes/$Volume`?api-version=$VolApi"
if (-not $src) { Die "volume $Volume not found in $VmName" }
$srcSerial = $src.properties.serialNumber
Log "source volume: $Volume (serial $srcSerial)"

if (ArmGet "$vgId/volumes/$NewVol`?api-version=$VolApi") {
  Die "$NewVol already exists in $VmName. Unmount and delete it first, or pick another suffix with -Suffix"
}

# --- snapshot ---
# The list doesn't carry volumeSnapshots, only a single GET does, so walk from
# newest to oldest until one holds this volume.
if ($Snapshot) {
  $candidates = @($Snapshot)
} else {
  $candidates = @((ArmGet "$vgId/snapshots?api-version=$SnapApi").value |
    Where-Object { -not $_.properties.softDeletion.destroyed } |
    Sort-Object { [datetime]$_.properties.createdAt } -Descending |
    Select-Object -ExpandProperty name)
}
if (-not $candidates) { Die "$VmName has no snapshots" }

$snapId = $null
foreach ($s in $candidates) {
  $body = ArmGet "$vgId/snapshots/$s`?api-version=$SnapApi"
  if ($body -and ($body.properties.volumeSnapshots | Where-Object name -eq $Volume)) {
    $snapId = "$vgId/snapshots/$s"
    Log "snapshot: $s (created $(([datetime]$body.properties.createdAt).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')))"
    break
  }
  if (-not $Snapshot) { Log "snapshot $s doesn't contain $Volume, trying older" }
}
if (-not $snapId) { Die "no snapshot of $VmName contains $Volume" }

if ($DryRun) {
  Log "dry run: would clone $Volume from $(Split-Path $snapId -Leaf) to $NewVol and mount it on $VmName (mount $MountPath, $Mode)"
  exit 0
}

# --- clone ---
# No provisionedSize: the clone takes the size the member snapshot was taken at.
$cloneBody = @{ properties = @{
    sourceType                  = "snapshot"
    sourceVolumeGroupResourceId = $vgId
    sourceVolumeSnapshot        = @{ volumeGroupSnapshotResourceId = $snapId; volumeSnapshotName = $Volume }
  } } | ConvertTo-Json -Depth 5 -Compress
$bodyFile = New-TemporaryFile
Set-Content -Path $bodyFile -Value $cloneBody
Log "creating $NewVol"
$null = AzJson rest --method put --url "$Arm$vgId/volumes/$NewVol`?api-version=$VolApi" --body "@$bodyFile"
Remove-Item $bodyFile

# Volumes don't report provisioningState; wait until the GET has a serial.
$newSerial = $null
for ($i = 0; $i -lt 36 -and -not $newSerial; $i++) {
  $newSerial = (ArmGet "$vgId/volumes/$NewVol`?api-version=$VolApi").properties.serialNumber
  if (-not $newSerial) { Start-Sleep 5 }
}
if (-not $newSerial) { Die "$NewVol never showed a serial number" }
Log "restored volume: $NewVol (serial $newSerial)"

# --- mount in the guest ---
Log "mounting on $VmName via Run Command"
$guest = Join-Path $PSScriptRoot "guest-mount.ps1"
$res = AzJson vm run-command invoke -g $ResourceGroup -n $VmName --command-id RunPowerShellScript `
  --scripts "@$guest" `
  --parameters "NewSerial=$newSerial" "SrcSerial=$srcSerial" "MountPath=$MountPath" "Mode=$Mode"
$stdout = ($res.value | Where-Object code -like "*StdOut*").message
$stderr = ($res.value | Where-Object code -like "*StdErr*").message
Write-Host $stdout
if ($stderr) { Write-Host $stderr -ForegroundColor Yellow }
if ($stdout -notmatch "(?m)^RESTORE_OK") { Die "guest mount failed. $NewVol was created and is left in place" }
Log "done"
