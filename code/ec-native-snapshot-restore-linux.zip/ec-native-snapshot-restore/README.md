# Everpure Cloud Azure Native snapshot recovery

Clones one volume from its latest volume group snapshot to `<volume>-restored` and mounts it on the VM next to the original, so you can copy back what you need.

| | Linux | Windows |
|---|---|---|
| Run from your workstation | `linux/ec-restore.sh` (bash, `az`, `jq`) | `windows/ec-restore-windows.ps1` (PowerShell 7, `az`) |
| Sent to the VM by Run Command | `linux/guest-mount.sh` (`RunShellScript`) | `windows/guest-mount.ps1` (`RunPowerShellScript`) |
| Finds the clone by | WWID `3624a9370` + serial | `Get-Disk` serial number |
| Duplicate filesystem / disk ID | XFS mounted with `nouuid` | Windows holds the disk offline (`Collision`); bringing it online writes a new disk GUID |
| Default mount | source mountpoint + `-restored` | next free drive letter |

Keep each script next to its guest script. Both do the same Azure API work:

1. Finds the volume group with the same name as the VM. It searches every `PureStorage.Block/storagePools` in the subscription, or only the pool you pass with `-p`.
2. Picks the newest snapshot that is not destroyed and contains the volume. If a volume was added after a snapshot, that snapshot is skipped.
3. PUTs `<volume>-restored` into the same volume group with `sourceType: snapshot`.
4. Runs the guest script through Run Command, which rescans storage, finds the new LUN and mounts it.

The clone goes into the volume group the VM is already connected to, so the MountIscsiLinux / MountIscsiWindows extension is not touched. A rescan is enough.

## Linux

```bash
./linux/ec-restore.sh -g <vm-rg> -n <vm-name> -v <volume> [-m /data-restored] [-s <snapshot>] [-r] [-d]
```

| flag | |
|---|---|
| `-m` | guest mountpoint. Default is the source volume's mountpoint plus `-restored`, or `/mnt/<volume>-restored` if the source isn't mounted |
| `-s` | use this snapshot instead of the latest |
| `-p` | storage pool resource ID, skips the search |
| `-x` | suffix, default `-restored` |
| `-r` | mount read-only |
| `-d` | dry run, resolves the VG, volume and snapshot and stops |

Needs `az` (logged in) and `jq`.

### Guest notes

- XFS clones are mounted with `nouuid`, because XFS won't mount two filesystems with the same UUID. ext4 doesn't need it.
- LVM is not handled. The clone carries the source PV and VG UUIDs, so the script stops and tells you to use `vgimportclone`.
- Nothing is written to `/etc/fstab`. The mount doesn't survive a reboot.

## Windows

```powershell
./windows/ec-restore-windows.ps1 -ResourceGroup <vm-rg> -VmName <vm-name> -Volume <volume> [-MountPath R: | C:\restored\data1] [-Snapshot <name>] [-ReadOnly] [-DryRun]
```

| parameter | |
|---|---|
| `-MountPath` | `auto` (default) for the next free drive letter, a letter like `R:`, or an empty folder like `C:\restored\data1` |
| `-Snapshot` | use this snapshot instead of the latest |
| `-Pool` | storage pool resource ID, skips the search |
| `-Suffix` | default `-restored` |
| `-ReadOnly` | set the disk read-only before it's mounted |
| `-DryRun` | resolves the VG, volume and snapshot and stops |

Needs PowerShell 7 and `az` (logged in). Runs from Windows, macOS or Linux.

### Guest notes

- The clone has the same disk GUID (GPT) or signature (MBR) as its source, so Windows keeps it offline with reason `Collision`. `Set-Disk -IsOffline $false` brings it up and writes a new GUID. With `-ReadOnly` the script clears read-only just long enough for that, then sets it back.
- Dynamic disks and Storage Spaces are not handled, for the same reason as LVM on Linux. The script stops.
- A BitLocker volume shows no filesystem until it's unlocked, so the script stops and says so.
- Run Command passes Windows parameters as `-Name value`, so no value can start with `-`. That's why the default is `auto`.
- Don't count on a fixed drive letter. On a fresh Azure VM `E:` is usually the CD-ROM.

## Checking on Run Command

The script uses the legacy Run Command (`az vm run-command invoke`). It has no status object to query, and only one can run on a VM at a time. A hung one also blocks other VM operations (restart included) until it times out after 90 minutes.

Handler state on the VM:

```bash
az vm get-instance-view -g <vm-rg> -n <vm-name> --query "instanceView.extensions[?type=='Microsoft.CPlat.Core.RunCommandLinux']" -o json
```

Run history:

```bash
az monitor activity-log list -g <vm-rg> --offset 2h --query "[?operationName.value=='Microsoft.Compute/virtualMachines/runCommand/action'].{s:status.value,t:eventTimestamp}" -o table
```

In the guest, the handler log is `/var/log/azure/run-command/handler.log`. Each run's script and output are in `/var/lib/waagent/run-command/download/<n>/` (`script.sh`, `stdout`, `stderr`).

If the guest is unreachable, the serial log still shows kernel messages such as hung tasks and multipath or ALUA errors:

```bash
az vm boot-diagnostics get-boot-log -g <vm-rg> -n <vm-name>
```

Managed run commands (`az vm run-command create`) are real resources and can be queried directly:

```bash
az vm run-command show -g <vm-rg> --vm-name <vm-name> --name <name> --instance-view --query "instanceView.{state:executionState,exit:exitCode,out:output,err:error}" -o json
```

## Inspecting the guest through Run Command

Every command here runs on the VM via `az vm run-command invoke -g <vm-rg> -n <vm-name> --command-id RunShellScript --scripts '<command>' --query "value[0].message" -o tsv`. Keep `timeout` on anything that touches a disk. A map with no live path queues I/O forever and takes Run Command down with it.

iSCSI sessions and which portal each one actually landed on (the array can redirect the login):

```bash
iscsiadm -m session -P1 | grep -E "Target:|Current Portal|Persistent Portal|Session State"
```

LUNs presented on each session. 0 on a logged-in session means the array isn't presenting the volume group's volumes to this host:

```bash
for s in /sys/class/iscsi_session/session*; do echo "$(basename $s) $(cat $s/targetname) LUNs=$(ls $s/device/target*/ 2>/dev/null | grep -c '^[0-9]*:[0-9]*:[0-9]*:[0-9]*$')"; done
```

Rescan, then multipath paths for one volume (WWID is `3624a9370` + the serial, lowercase). A healthy volume shows 4 paths, `active ready running`, split into a prio 50 group (ct0) and a prio 10 group (ct1):

```bash
timeout 60 iscsiadm -m session --rescan; timeout 30 multipath -r; timeout 20 multipath -ll 3624a9370<serial>
```

ALUA and path errors in the kernel log. `alua: rtpg failed` on every path at once usually means the LUN stopped being presented:

```bash
dmesg -T | grep -iE "rtpg|alua|offline device|I/O error" | tail -20
```

TCP reachability of the iSCSI portals, no `nc` needed:

```bash
for ip in <ct0-ip> <ct1-ip>; do timeout 3 bash -c "</dev/tcp/$ip/3260" && echo "$ip open" || echo "$ip FAILED"; done
```

What earlier Run Commands did. Each run is numbered under `download/`, newest first. `script.sh` is what ran (for a restore it's `guest-mount.sh`), and `stdout`/`stderr` are its output:

```bash
d=/var/lib/waagent/run-command/download; for n in $(ls -t $d | head -3); do echo "## run $n $(stat -c %y $d/$n/script.sh | cut -c1-19)"; head -3 $d/$n/script.sh; echo "-- stdout"; cat $d/$n/stdout; echo "-- stderr"; cat $d/$n/stderr; done
```

```bash
tail -20 /var/log/azure/run-command/handler.log
```

What the MountIscsiLinux extension did (one log per enable; look for `login succeeded`, `Skipping iSCSI login`, `Could not login`):

```bash
d=/var/log/azure/PureStorage.Extensions.MountIscsiLinux; grep -hE "login|Resolved|error" $(ls -t $d/pure-*.log | head -1) | cut -c1-200
```

## Cleanup

Take the clone out of the guest first, then delete it in Azure. On Linux the order matters: delete the volume while its multipath map is still there and the map is left with failed paths and `queue_if_no_path`, so anything that reads it later can hang.

Linux, in the guest through Run Command (WWID is `3624a9370` + the clone's serial, lowercase):

```bash
W=3624a9370<serial>
umount /mnt/data1-restored
DM=$(basename "$(readlink -f /dev/mapper/$W)"); PATHS=$(ls /sys/block/$DM/slaves)
multipath -f $W
for d in $PATHS; do echo 1 > /sys/block/$d/device/delete; done
```

Windows, in the guest through Run Command (remove a folder mount point first with `Remove-PartitionAccessPath`):

```powershell
Get-Disk | Where-Object SerialNumber -eq "<serial>" | Set-Disk -IsOffline $true
```

Then, from your workstation, delete the volume:

```bash
az rest --method delete --url "https://management.azure.com<vg-id>/volumes/<volume>-restored?api-version=2026-05-01-preview"
```

No rescan is needed on Linux. On Windows, `Update-HostStorageCache` clears the dead disk right away instead of waiting for MPIO's `PDORemovePeriod`.

If the volume was already deleted on Linux, run `dmsetup message $W 0 fail_if_no_path` before `multipath -f $W`.
