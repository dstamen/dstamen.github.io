#!/bin/bash
# Runs inside the Linux guest via Run Command (RunShellScript). Rescans iSCSI,
# finds the restored Everpure volume by serial and mounts it.
#
# Positional args (Run Command passes --parameters positionally):
#   $1  serial of the restored volume
#   $2  serial of the source volume (used to find its mountpoint)
#   $3  mountpoint, or "-" to derive it (<source mountpoint>-restored)
#   $4  "ro" to mount read-only, "rw" otherwise
#   $5  restored volume name (fallback mountpoint /mnt/<name>)
set -u

NEW_SERIAL=$(echo "$1" | tr 'A-Z' 'a-z')
SRC_SERIAL=$(echo "$2" | tr 'A-Z' 'a-z')
MOUNTPOINT=$3
MODE=$4
NAME=$5

fail() { echo "RESTORE_ERROR: $*"; exit 1; }

# Everpure volumes show up with NAA WWID 3624a9370 + serial.
NEW_WWID="3624a9370$NEW_SERIAL"
SRC_WWID="3624a9370$SRC_SERIAL"

# Resolve a WWID to a block device: multipath map first, then a single path.
dev_for() {
  local wwid=$1 d
  for d in "/dev/disk/by-id/dm-uuid-mpath-$wwid" "/dev/disk/by-id/scsi-$wwid" "/dev/disk/by-id/wwn-0x${wwid#3}"; do
    [ -e "$d" ] && { readlink -f "$d"; return 0; }
  done
  return 1
}

# The clone lives in the volume group the VM is already logged in to, so a
# session rescan is enough to surface the new LUN. No extension change needed.
DEV=""
for _ in $(seq 1 24); do
  timeout 30 iscsiadm -m session --rescan >/dev/null 2>&1
  command -v multipath >/dev/null && timeout 30 multipath -r >/dev/null 2>&1
  timeout 30 udevadm settle >/dev/null 2>&1
  DEV=$(dev_for "$NEW_WWID") && break
  sleep 5
done
[ -n "$DEV" ] || fail "restored volume (serial $NEW_SERIAL) did not appear after rescan"
echo "restored device: $DEV"

# Everpure maps use queue_if_no_path, so any read against a map with no live
# path blocks forever, and takes Run Command down with it. Wait for a path
# first, and put a timeout on everything that touches the device.
if command -v multipath >/dev/null && [[ $DEV == /dev/dm-* ]]; then
  for _ in $(seq 1 24); do
    timeout 30 multipath -ll "$NEW_WWID" 2>/dev/null | grep -q "active ready running" && break
    sleep 5
  done
  timeout 30 multipath -ll "$NEW_WWID" 2>/dev/null | grep -q "active ready running" ||
    fail "$DEV has no active paths: $(timeout 10 multipath -ll "$NEW_WWID" 2>&1 | tr '\n' ' ')"
fi

# Pick the filesystem: the device itself, or its first partition that has one.
PART=$DEV
FSTYPE=$(timeout 30 blkid -o value -s TYPE "$DEV" 2>/dev/null)
if [ -z "$FSTYPE" ]; then
  command -v kpartx >/dev/null && timeout 30 kpartx -a "$DEV" >/dev/null 2>&1 && timeout 30 udevadm settle >/dev/null 2>&1
  read -r PART FSTYPE < <(timeout 30 lsblk -nrp -o PATH,FSTYPE "$DEV" | awk -v d="$DEV" '$1 != d && $2 != "" {print; exit}')
fi
[ -n "${FSTYPE:-}" ] || fail "no filesystem found on $DEV (or blkid timed out)"
case $FSTYPE in
  LVM2_member) fail "$PART is an LVM PV. A clone shares the source PV/VG UUIDs; import it with 'vgimportclone' and mount the LV by hand" ;;
  swap) fail "$PART is swap, nothing to mount" ;;
esac
echo "filesystem: $FSTYPE on $PART"

# Default mountpoint: wherever the source volume is mounted, plus -restored.
if [ "$MOUNTPOINT" = "-" ]; then
  SRC_DEV=$(dev_for "$SRC_WWID")
  SRC_MNT=""
  if [ -n "$SRC_DEV" ]; then
    SRC_MNT=$(timeout 30 lsblk -nrp -o MOUNTPOINT "$SRC_DEV" | awk 'NF {print; exit}')
  fi
  if [ -n "$SRC_MNT" ] && [ "$SRC_MNT" != "/" ]; then
    MOUNTPOINT="${SRC_MNT}-restored"
  else
    MOUNTPOINT="/mnt/$NAME"
  fi
fi

if mountpoint -q "$MOUNTPOINT"; then
  findmnt -n -o SOURCE "$MOUNTPOINT" | grep -q "$(basename "$PART")" &&
    { echo "already mounted at $MOUNTPOINT"; echo "RESTORE_OK $PART $MOUNTPOINT"; exit 0; }
  fail "$MOUNTPOINT already has something else mounted on it"
fi
mkdir -p "$MOUNTPOINT"

# XFS refuses to mount a second filesystem with the same UUID as one already
# mounted, which is exactly what a clone is. ext4 doesn't care.
OPTS=""
[ "$FSTYPE" = xfs ] && OPTS="nouuid"
[ "$MODE" = ro ] && OPTS="${OPTS:+$OPTS,}ro"

timeout 120 mount ${OPTS:+-o "$OPTS"} "$PART" "$MOUNTPOINT" || fail "mount $PART $MOUNTPOINT failed"
echo "mounted $PART at $MOUNTPOINT (${OPTS:-defaults})"
echo "RESTORE_OK $PART $MOUNTPOINT"
