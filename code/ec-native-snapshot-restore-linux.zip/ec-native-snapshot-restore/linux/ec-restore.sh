#!/bin/bash
# Restore one Everpure Cloud Azure Native volume from its latest snapshot and
# mount it side by side on the VM.
#
#   VM name -> volume group of the same name (searched across storage pools)
#   latest volume group snapshot that contains the volume
#   clone that member snapshot to <volume>-restored in the same volume group
#   Run Command on the guest: rescan iSCSI, mount it at <mountpoint>-restored
#
# Needs: az (logged in), jq.
set -euo pipefail

VG_API=2026-05-01-preview
VOL_API=2026-05-01-preview
SNAP_API=2026-05-01-preview
ARM=https://management.azure.com
HERE=$(cd "$(dirname "$0")" && pwd)

usage() {
  cat <<EOF
Usage: $0 -g <vm-rg> -n <vm-name> -v <volume> [options]

  -g  VM resource group
  -n  VM name (also the volume group name)
  -v  volume to restore
  -m  mountpoint in the guest (default: source mountpoint + -restored,
      or /mnt/<volume>-restored if the source isn't mounted)
  -s  snapshot name to use instead of the latest
  -p  storage pool resource ID (default: search every pool in the subscription)
  -x  suffix for the new volume (default: -restored)
  -r  mount read-only
  -d  dry run: resolve everything, change nothing
EOF
  exit 1
}

RG="" VM="" VOL="" MNT="-" SNAP="" POOL="" SUFFIX="-restored" MODE=rw DRY=0
while getopts "g:n:v:m:s:p:x:rdh" o; do
  case $o in
    g) RG=$OPTARG ;; n) VM=$OPTARG ;; v) VOL=$OPTARG ;; m) MNT=$OPTARG ;;
    s) SNAP=$OPTARG ;; p) POOL=$OPTARG ;; x) SUFFIX=$OPTARG ;;
    r) MODE=ro ;; d) DRY=1 ;; *) usage ;;
  esac
done
[ -n "$RG" ] && [ -n "$VM" ] && [ -n "$VOL" ] || usage
[ "$MNT" = "-" ] || [[ $MNT =~ ^/[A-Za-z0-9._/-]+$ ]] || { echo "mountpoint must be an absolute path"; exit 1; }

NEW_VOL="$VOL$SUFFIX"
log() { echo "==> $*"; }
die() { echo "ERROR: $*" >&2; exit 1; }

# GET that returns the body on 200 and nothing on 404, instead of failing.
arm_get() { az rest --method get --url "$ARM$1" 2>/dev/null || true; }

# --- VM ---
OS=$(az vm show -g "$RG" -n "$VM" --query storageProfile.osDisk.osType -o tsv) || die "VM $RG/$VM not found"
[ "$OS" = Linux ] || die "$VM is $OS; this script mounts with the Linux Run Command"
POWER=$(az vm get-instance-view -g "$RG" -n "$VM" --query "instanceView.statuses[?starts_with(code,'PowerState/')].code | [0]" -o tsv)
[ "$POWER" = PowerState/running ] || die "$VM is $POWER; Run Command needs it running"

# --- volume group (same name as the VM) ---
if [ -n "$POOL" ]; then
  POOLS=$POOL
else
  POOLS=$(az resource list --resource-type PureStorage.Block/storagePools --query "[].id" -o tsv)
fi
VG_ID=""
for p in $POOLS; do
  if [ -n "$(arm_get "$p/volumeGroups/$VM?api-version=$VG_API")" ]; then
    VG_ID="$p/volumeGroups/$VM"
    break
  fi
done
[ -n "$VG_ID" ] || die "no volume group named $VM in: $POOLS"
log "volume group: $VG_ID"

SRC=$(arm_get "$VG_ID/volumes/$VOL?api-version=$VOL_API")
[ -n "$SRC" ] || die "volume $VOL not found in $VM"
SRC_SERIAL=$(echo "$SRC" | jq -r .properties.serialNumber)
log "source volume: $VOL (serial $SRC_SERIAL)"

[ -z "$(arm_get "$VG_ID/volumes/$NEW_VOL?api-version=$VOL_API")" ] ||
  die "$NEW_VOL already exists in $VM. Unmount and delete it first, or pick another suffix with -x"

# --- snapshot ---
# The list doesn't carry volumeSnapshots, only a single GET does, so walk from
# newest to oldest until one holds this volume (a volume added after a snapshot
# won't be in it).
if [ -n "$SNAP" ]; then
  CANDIDATES=$SNAP
else
  CANDIDATES=$(az rest --method get --url "$ARM$VG_ID/snapshots?api-version=$SNAP_API" |
    jq -r '[.value[] | select(.properties.softDeletion.destroyed != true)]
           | sort_by(.properties.createdAt) | reverse | .[].name')
fi
[ -n "$CANDIDATES" ] || die "$VM has no snapshots"

SNAP_ID=""
for s in $CANDIDATES; do
  body=$(arm_get "$VG_ID/snapshots/$s?api-version=$SNAP_API")
  [ -n "$body" ] || continue
  if echo "$body" | jq -e --arg v "$VOL" '.properties.volumeSnapshots[]? | select(.name == $v)' >/dev/null; then
    SNAP_ID="$VG_ID/snapshots/$s"
    log "snapshot: $s (created $(echo "$body" | jq -r .properties.createdAt))"
    break
  fi
  [ -n "$SNAP" ] || log "snapshot $s doesn't contain $VOL, trying older"
done
[ -n "$SNAP_ID" ] || die "no snapshot of $VM contains $VOL"

if [ "$DRY" = 1 ]; then
  log "dry run: would clone $VOL from ${SNAP_ID##*/} to $NEW_VOL and mount it on $VM (mountpoint ${MNT/#-/auto}, $MODE)"
  exit 0
fi

# --- clone ---
# No provisionedSize: the clone takes the size the member snapshot was taken at.
BODY=$(jq -nc --arg vg "$VG_ID" --arg snap "$SNAP_ID" --arg vol "$VOL" '{properties: {
  sourceType: "snapshot",
  sourceVolumeGroupResourceId: $vg,
  sourceVolumeSnapshot: {volumeGroupSnapshotResourceId: $snap, volumeSnapshotName: $vol}}}')
log "creating $NEW_VOL"
az rest --method put --url "$ARM$VG_ID/volumes/$NEW_VOL?api-version=$VOL_API" --body "$BODY" >/dev/null

# Volumes don't report provisioningState; wait until the GET has a serial.
NEW_SERIAL=""
for _ in $(seq 1 36); do
  NEW_SERIAL=$(arm_get "$VG_ID/volumes/$NEW_VOL?api-version=$VOL_API" | jq -r '.properties.serialNumber // empty' 2>/dev/null || true)
  [ -n "$NEW_SERIAL" ] && break
  sleep 5
done
[ -n "$NEW_SERIAL" ] || die "$NEW_VOL never showed a serial number"
log "restored volume: $NEW_VOL (serial $NEW_SERIAL)"

# --- mount in the guest ---
log "mounting on $VM via Run Command"
OUT=$(az vm run-command invoke -g "$RG" -n "$VM" --command-id RunShellScript \
  --scripts @"$HERE/guest-mount.sh" \
  --parameters "$NEW_SERIAL" "$SRC_SERIAL" "$MNT" "$MODE" "$NEW_VOL" \
  --query "value[0].message" -o tsv)
echo "$OUT"
echo "$OUT" | grep -q '^RESTORE_OK' || die "guest mount failed. $NEW_VOL was created and is left in place"
log "done"
